<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Buscom
 */

get_header();

buscom_breadcrumb();

if( is_page( 'cart' ) ){
    $section_class = "shop-cart-area validthemes-woocommerce-default default-padding";
}elseif( is_page( 'checkout' ) ){
    $section_class = "buscom-shop-check-out-area default-padding";
}elseif( is_page('wishlist') ){
    $section_class = "buscom-shop-wishlist-area validthemes-woocommerce-default default-padding";
}elseif(is_page('my-account')){
    $section_class = "buscom-shop-login-area validthemes-woocommerce-default default-padding";
}else{
	$section_class = "page-entry default-padding";
}
?>



<div class="<?php echo esc_attr($section_class); ?>">
	<div class="container">
		<div class="row">
		<?php
			if( have_posts() ) {

				while( have_posts() ) : the_post();
					get_template_part('template-parts/content','page');
				endwhile;

				// If comments are open or we have at least one comment, load up the comment template.
				if( comments_open() || get_comments_number() ):
					comments_template();
				endif;

			} else {
				get_template_part('template-parts/content', 'none');
		} ?>
		</div>
	</div>
</div>
<?php get_footer( ); 