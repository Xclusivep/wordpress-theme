<?php
/**
 * The sidebar containing the service page widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package BUSCOM
 */

$sidebar = 'service-single-sidebar';

if ( ! is_active_sidebar( $sidebar ) ) {
    return;
}
?>
<div class="sidebar col-md-4">
    <?php dynamic_sidebar( $sidebar ); ?>
</div>