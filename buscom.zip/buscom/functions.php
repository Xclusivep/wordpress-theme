<?php
/**
 * Buscom functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Buscom
 */

if ( ! function_exists( 'buscom_basic_setup' ) ) {
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	require_once( get_theme_file_path( '/inc/plugin-activation.php' ) );
	require_once( get_theme_file_path( '/inc/buscom-navwalker.php' ) );
	
	function buscom_basic_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on _s, use a find and replace
		 * to change 'buscom' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'buscom', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );
		
		add_theme_support( 'editor-style' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus( array(
			'primary' => esc_html__( 'Primary', 'buscom' ),
		) );

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'script',
			'style'
		));

		remove_theme_support( 'widgets-block-editor' );



		/*
		 * Enable support for Woocommerce.
		 *
		 */

		add_theme_support( 'woocommerce' );

		 /*
		 * Enable support for Post Formats.
		 *
		 * See: https://codex.wordpress.org/Post_Formats
		 */
		add_theme_support( 'post-formats', array(
			'audio',
			'video',
			'quote',
			'link',
			'image',
			'gallery',
			'aside',
		) );
		
		// Image sizes
		add_image_size( 'buscom_50x50', 50, 50, true );
		add_image_size( 'buscom_371x371', 371, 371, true );
		add_image_size( 'buscom_370x277', 370, 277, true );
		add_image_size( 'buscom_360x270', 360, 270, true );
		add_image_size( 'buscom_945x441', 945, 441, true );
		add_image_size( 'buscom_750x500', 750, 500, true );
		add_image_size( 'buscom_100x100', 100, 100, true );
		add_image_size( 'buscom_80x80', 80, 80, true );
		add_image_size( 'buscom_800x800', 800, 800, true );
		add_image_size( 'buscom_1140x532', 1140, 532, true );
	}
}
add_action( 'after_setup_theme', 'buscom_basic_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
if ( ! function_exists( 'buscom_content_width' ) ) {
	function buscom_content_width() {
	    // This variable is intended to be overruled from themes.
	    // Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
	    // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
	    $GLOBALS['content_width'] = apply_filters( 'buscom_content_width', 640 );
	}
}
add_action( 'after_setup_theme', 'buscom_content_width', 0 );

/**
 * Register custom fonts.
 */
if ( ! function_exists( 'buscom_google_fonts' ) ) :
/**
 * Register Google fonts for Blessing.
 *
 * Create own buscom_google_fonts() function to override in a child theme.
 *
 * @since Blessing 1.0
 *
 * @return string Google fonts URL for the theme.
 */
	function buscom_google_fonts() {
	    $font_url = '';

	    /*
	    Translators: If there are characters in your language that are not supported
	    by chosen font(s), translate this to 'off'. Do not translate into your own language.
	     */
	    if ( 'off' !== _x( 'on', 'Google font: on or off', 'buscom' ) ) {
	        $font_url =  'https://fonts.googleapis.com/css2?family=Yantramanav:wght@100;300;400;500;700;900&display=swap';
	    }
	    return $font_url;
	}
endif;



/**
 * Enqueue scripts and styles.
 */
function buscom_add_script() {

	// Add custom fonts, used in the main stylesheet.
	wp_enqueue_style( 'buscom-fonts', buscom_google_fonts(), array(), null );

	wp_enqueue_style( 'bootstrap', get_template_directory_uri() . '/assets/css/bootstrap.min.css', null, "1.0" );
	wp_enqueue_style( 'fontawesome', get_template_directory_uri() . '/assets/css/fontawesome.min.css', null, "1.0" );
	wp_enqueue_style( 'themify-icons', get_template_directory_uri() . '/assets/css/themify-icons.css', null, "1.0" );
	wp_enqueue_style( 'elegant-icons', get_template_directory_uri() . '/assets/css/elegant-icons.css', null, "1.0" );
	wp_enqueue_style( 'flaticon-set', get_template_directory_uri() . '/assets/css/flaticon-set.css', null, "1.0" );
	wp_enqueue_style( 'magnific-popup', get_template_directory_uri() . '/assets/css/magnific-popup.css', null, "1.0" );
	wp_enqueue_style( 'owl-carousel', get_template_directory_uri() . '/assets/css/owl.carousel.min.css', null, "1.0" );
    wp_enqueue_style( 'owl-theme', get_template_directory_uri() . '/assets/css/owl.theme.min.css', null, "1.0" );
    wp_enqueue_style( 'animate', get_template_directory_uri() . '/assets/css/animate.css', null, "1.0" );
    wp_enqueue_style( 'buscom-shop-style', get_template_directory_uri() . '/assets/css/shop.css', null, "1.0" );
	wp_enqueue_style( 'bootsnav', get_template_directory_uri() . '/assets/css/bootsnav.css', null, "1.0" );
	wp_enqueue_style( 'buscom-main-style', get_template_directory_uri() . '/assets/css/style.css', null, "1.0" );
    wp_enqueue_style( 'buscom-responsive', get_template_directory_uri() . '/assets/css/responsive.css', null, "1.0" );

    wp_enqueue_style( 'buscom-style', get_stylesheet_uri() ,array(), wp_get_theme()->get( 'Version' ) );

    wp_enqueue_script( 'bootstrap', get_template_directory_uri() . '/assets/js/bootstrap.min.js', array( 'jquery' ), false, true );
    wp_enqueue_script( 'equal-height', get_template_directory_uri() . '/assets/js/equal-height.min.js', array( 'jquery' ), false, true );
    wp_enqueue_script( 'jquery-appear', get_template_directory_uri() . '/assets/js/jquery.appear.js', array( 'jquery' ), false, true );
    wp_enqueue_script( 'jquery-easing', get_template_directory_uri() . '/assets/js/jquery.easing.min.js', array( 'jquery' ), false, true );
    wp_enqueue_script( 'jquery-magnific-popup', get_template_directory_uri() . '/assets/js/jquery.magnific-popup.min.js', array( 'jquery' ), false, true );
    wp_enqueue_script( 'modernizr', get_template_directory_uri() . '/assets/js/modernizr.js', array( 'jquery' ), false, true );
    wp_enqueue_script( 'owl-carousel', get_template_directory_uri() . '/assets/js/owl.carousel.min.js', array( 'jquery' ), false, true );
    wp_enqueue_script( 'wow', get_template_directory_uri() . '/assets/js/wow.min.js', array( 'jquery' ), false, true );
    wp_enqueue_script( 'progress-bar', get_template_directory_uri() . '/assets/js/progress-bar.min.js', array( 'jquery' ), false, true );
    wp_enqueue_script( 'isotope-pkgd', get_template_directory_uri() . '/assets/js/isotope.pkgd.min.js', array( 'jquery' ), false, true );
    wp_enqueue_script( 'imagesloaded-pkgd', get_template_directory_uri() . '/assets/js/imagesloaded.pkgd.min.js', array( 'jquery' ), false, true );
    
	    wp_enqueue_script( 'jquery-nice-select', get_template_directory_uri() . '/assets/js/jquery.nice-select.min.js', array( 'jquery' ), false, true );
	wp_enqueue_script( 'count-to', get_template_directory_uri() . '/assets/js/count-to.js', array( 'jquery' ), false, true );
	wp_enqueue_script( 'YTPlayer', get_template_directory_uri() . '/assets/js/YTPlayer.min.js', array( 'jquery' ), false, true );
	wp_enqueue_script( 'circle-progress', get_template_directory_uri() . '/assets/js/circle-progress.js', array( 'jquery' ), false, true );
	wp_enqueue_script( 'bootsnav', get_template_directory_uri() . '/assets/js/bootsnav.js', array( 'jquery' ), false, true );
	if( class_exists( 'WooCommerce' ) ){
	    wp_enqueue_script( 'buscom-custom-input-number', get_template_directory_uri() . '/assets/js/custom-input-number.js', array( 'jquery' ), false, true );
	}
	wp_enqueue_script( 'buscom-main-script', get_template_directory_uri() . '/assets/js/main.js', array( 'jquery' ), false, true );

 
    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
	}
}
add_action('wp_enqueue_scripts', 'buscom_add_script' );

/**
* Helper file
*/
require get_template_directory() . '/inc/buscom-helper.php';

/**
 * Header File
 */
require get_template_directory() . '/inc/buscom-header.php';

/**
 * Breadcumb File
 */
require get_template_directory() . '/inc/buscom-breadcumb.php';

/**
 * Load theme options.
 */
require get_template_directory() . '/inc/redux-config.php';

/**
* Demo File
*/
require get_template_directory() . '/inc/demo_config.php';

/**
* woo-hooks
*/
require get_template_directory() . '/inc/woocommerce-hooks/woocommerce-hooks.php';

/**
* woo-hooks function
*/
require get_template_directory() . '/inc/woocommerce-hooks/woocommerce-hooks-function.php';