<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package BUSCOM
 */

$sidebar = 'primary-sidebar';

if ( ! is_active_sidebar( $sidebar ) ) {
    return;
}
?>
<!-- Start Sidebar -->
<div class="sidebar col-md-4">
    <aside>
        <?php dynamic_sidebar( $sidebar ); ?>
    </aside>
</div>
<!-- End Sidebar -->