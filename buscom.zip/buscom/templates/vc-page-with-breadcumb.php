<?php
/**
 * Template Name: VC Page With Breadcumb
 * Description: The template file for displaying home page
 *
 * @package BUSCOM
 */

get_header();
buscom_breadcrumb();
	while ( have_posts() ) : the_post();

		the_content();

		// If comments are open or we have at least one comment, load up the comment template.
		if ( comments_open() || get_comments_number() ) :
			comments_template();
		endif;

	endwhile; // End of the loop.
get_footer();