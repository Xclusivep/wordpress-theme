<?php
/**
 * The template for displaying comments
 *
 * This is the template that displays the area of the page that contains both the current comments
 * and the comment form.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package BUSCOM
 */ 
 
/**
 * If the current post is protected by a password and
 * the visitor has not yet entered the password we will
 * return early without loading the comments.
 */
if ( post_password_required() ) return; ?>
<!-- Start comments-area -->
<div class="comments-area">
    <?php if(have_comments()): ?>
        <?php if( get_comments_number() >= 1 ): ?>
            <div class="comments-title">
                <h4>
                    <?php
                    $buscom_comment_count = get_comments_number();
                    if ( '1' === $buscom_comment_count ) {
                        printf(
                        /* translators: 1: title. */
                            esc_html__( 'One Comment', 'buscom' ),
                            '<span>' . get_the_title() . '</span>'
                        );
                    } else {
                        printf( // WPCS: XSS OK.
                        /* translators: 1: comment count number, 2: title. */
                            esc_html( _nx( '%1$s Comment on &ldquo;%2$s&rdquo;', '%1$s Comments on &ldquo;%2$s&rdquo;', $buscom_comment_count, 'comments title','buscom' ) ),
                            number_format_i18n( $buscom_comment_count ),
                            '<span>' . get_the_title() . '</span>'
                        );
                    }
                    ?>
                </h4>
                <ul class="comments-list">
                    <?php wp_list_comments( array( 'callback' => 'buscom_comments' ) ); ?>
                </ul>
                <?php if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) : // are there comments to navigate through ?>
                    <?php
                    next_comments_link('<span class="buscom-n-com">'.esc_html__('Next','buscom').'</span>');
                    previous_comments_link('<span class="buscom-p-com">'.esc_html__('Prev','buscom').'</span>');
                    ?>
                <?php endif; // check for comment navigation ?> 
            </div>
        <?php endif;  ?>
    <?php  endif; // if have_comments(). ?>
    <div class="comments-form">
        <?php
        $commenter = wp_get_current_commenter();
        $req = get_option( 'require_name_email' );
        $aria_req = $req ? " aria-required='true'" : '';
        $required_text = '  ';

        $args = array (
            'class_form'  => 'comment-form',
            'title_reply' => '<div class="title mb-30">'.esc_html__('Leave a comment', 'buscom').'</div>',
            'submit_button' => '<button class="btn brand-btn" type="submit">'.esc_html__('Post Comment','buscom').'</button>',
            'cancel_reply_link' => esc_html__('Cancel reply','buscom'),
            'comment_notes_before' => '',
            'comment_field' =>
               '<div class="row"><div class="col-md-12"><div class="form-group comments">
                    <textarea  class="form-control" name="comment" id="comment" cols="90" rows="8" placeholder="'.esc_html__(' Comment','buscom').'"  name="comment"'.$aria_req.'></textarea>
                </div></div>',
            'fields' =>
                apply_filters( 'comment_form_default_fields',
                    array(
                        'author' =>
                        '<div class="row"><div class="col-md-6"><div class="form-group">
                        <input type="text" class="form-control" placeholder="'.esc_html__('Name*','buscom').'" name="author" id="author" value="' . esc_attr( $commenter['comment_author'] ) . '" ' . $aria_req . ' />
                        </div></div>',
                        'email' => 
                        '<div class="col-md-6"><div class="form-group">
                        <input id="email"  class="form-control" placeholder="'.esc_html__('Email*','buscom').'" name="email" type="text" value="' . esc_attr(  $commenter['comment_author_email'] ) . '" ' . $aria_req . ' />
                        </div></div></div>'
                )   ),
            'submit_field' => '<div class="form-group full-width submit">%1$s %2$s</div></div>',
            'label_submit' => esc_html__('Send message','buscom'),
        );
        comment_form($args);
        ?>
    </div>
</div>
<!-- End comments-area -->