<?php
/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package BUSCOM
 */

get_header();
$buscom_opt = get_option('buscom_redux_opt');
buscom_breadcrumb();
?>
<!-- Start Blog
============================================= -->
<?php
if( isset( $buscom_opt['blog_sidebar'] ) ) { 
    if( $buscom_opt['blog_sidebar'] == '1' ){
        $layout = 'blog-standard';
    } elseif( $buscom_opt['blog_sidebar'] == '3' ){
        $layout = 'left-sidebar';
    } else {
        $layout = 'right-sidebar';
    }
} else {
    $layout = 'right-sidebar';
}
?>
<div class="blog-area full-blog <?php echo esc_attr( $layout ); ?> full-blog default-padding">
    <div class="container">
        <div class="row">
            <div class="blog-items">
                <?php
                if( isset( $buscom_opt['blog_sidebar'] ) && $buscom_opt['blog_sidebar'] == '1' ) :
                    echo '<div class="blog-content col-md-10 col-md-offset-1">';
                else :
                    echo '<div class="blog-content col-md-8">';
                endif; ?>
                    <div class="blog-item-box">
                        <?php
                            if ( have_posts() ) :

                                /* Start the Loop */
                                while ( have_posts() ) : the_post();
                                    /**
									 * Run the loop for the search to output the results.
									 * If you want to overload this in a child theme then include a file
									 * called content-search.php and that will be used instead.
									 */
                                    get_template_part( 'template-parts/content', 'search' );
                                endwhile;
                                /* End the Loop */
                            else :

                                get_template_part( 'template-parts/content', 'none' );                               
                            endif;
                        ?>
                    </div>
                    
                    <!-- Start Pagination -->
                    <div class="row">
                        <div class="col-md-12 pagi-area">
                            <nav aria-label="navigation">
                                <?php buscom_pagination(); ?>
                            </nav>
                        </div>
                    </div>

                    <!-- End Pagination -->
                </div>
                <?php
                if(isset( $buscom_opt['blog_sidebar']) && $buscom_opt['blog_sidebar'] == '1' ) :
                    echo "";
                else : 
                    get_sidebar();
                endif;
                ?>
            </div>
        </div>
    </div>
</div>
<!-- End Blog -->
<?php get_footer( );