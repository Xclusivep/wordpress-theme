<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package BUSCOM
 */

 get_header( ); 
 $buscom_opt = get_option('buscom_redux_opt');
 buscom_breadcrumb(); 
 ?>
<!-- Start Blog
============================================= -->
<?php
$sidebar_position = $buscom_opt['blog_sidebar'];
$buscom_overide_sidebar_position =isset($_GET['sb'])? $_GET['sb']:$sidebar_position;
?>
<div class="blog-area full-blog <?php if(isset($buscom_overide_sidebar_position)){ if($buscom_overide_sidebar_position == '3'){ echo "left-sidebar";} elseif($buscom_overide_sidebar_position == '1'){echo "blog-standard";} else{ echo "right-sidebar";}}else { echo "right-sidebar";} ?> full-blog default-padding">
    <div class="container">
        <div class="row">
            <div class="blog-items">
                <div class="<?php if($buscom_overide_sidebar_position == '1'){echo "blog-content col-md-10 col-md-offset-1";}else{echo "blog-content col-md-8 ";}?>">
                    <div class="blog-item-box">
                        <?php
                            if ( have_posts() ) :

                                /* Start the Loop */
                                while ( have_posts() ) : the_post();
                                    /*
                                     * Include the Post-Type-specific template for the content.
                                     * If you want to override this in a child theme, then include a file
                                     * called content-___.php (where ___ is the Post Type name) and that will be used instead.
                                     */
                                    get_template_part( 'template-parts/content', get_post_format() );

                                endwhile;
                                /* End the Loop */
                            else :

                                get_template_part( 'template-parts/content', 'none' );
                                
                            endif;
                        ?>
                    </div>
                    
                    <!-- Start Pagination -->
                    <div class="row">
                        <div class="col-md-12 pagi-area">
                            <nav aria-label="navigation">
                                <?php buscom_pagination(); ?>
                            </nav>
                        </div>
                    </div>

                    <!-- End Pagination -->
                </div>
                <?php 
                if($buscom_overide_sidebar_position == '1'){
					echo "";
				}else{
					get_sidebar();
				}
                ?>
            </div>
        </div>
    </div>
</div>
<!-- End Blog -->
<?php get_footer( );