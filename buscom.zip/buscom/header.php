<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <!-- ========== Meta Tags ========== -->
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- ========== Favicon Icon ========== -->
    <?php 
    $buscom_opt = get_option('buscom_redux_opt'); 
    $def_fav_icon = get_template_directory_uri() .'/assets/img/favicon.png'; ?>

    <link rel="shortcut icon" href="<?php if(isset($buscom_opt['favicon'])){ echo 
        esc_url($buscom_opt['favicon']['url']);} else { echo esc_url( $def_fav_icon );} ?>">

    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?> >
    <?php 
    buscom_body_open();
    buscom_popup_subscribe_form(); 
    do_action( 'buscom_header'); ?>

