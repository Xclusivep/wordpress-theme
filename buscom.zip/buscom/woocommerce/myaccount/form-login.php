<?php
/**
 * Login Form
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/myaccount/form-login.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce/Templates
 * @version 4.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

do_action( 'woocommerce_before_customer_login_form' ); ?>
    <div class="col-md-6 col-md-offset-3">
        <div class="form-tab-item-box">

                <!-- Tab Buttons -->
                <ul class="nav nav-pills">
                    <li class="active"><a data-toggle="tab" href="#login" aria-expanded="true"><?php esc_html_e( 'Log In','buscom'); ?></a></li>
                    <?php
                        if ( get_option( 'woocommerce_enable_myaccount_registration' ) === 'yes' ) :
                    ?>
                    <li><a data-toggle="tab" href="#register" aria-expanded="true"><?php esc_html_e( 'Register','buscom'); ?></a></li>
                    <?php
                        endif;
                    ?>
                </ul>
                <!-- End Tab Buttons -->

                <!-- Tab Content -->
                <div class="tab-content tab-content-info">

                    <div id="login" class="tab-pane fade active in">
                        <!-- Login Form -->
                        <?php
                            echo '<form method="post" class="woocommerce-form woocommerce-form-login login white-popup-block">';
                                do_action( 'woocommerce_login_form_start' );

                                echo '<div class="login-custom">';

                                    echo'<div class="col-md-12"><div class="row"><div class="form-group">';
                                        $username_value = ! empty( $_POST['username'] ) ? wp_unslash( $_POST['username'] ) : '';
                                        echo '<input type="text" class="woocommerce-Input woocommerce-Input--text input-text form-control" name="username" id="username" value="'.esc_attr( $username_value ) .'">';
                                    echo'</div></div></div>';

                                    echo'<div class="col-md-12"><div class="row"><div class="form-group">';
                                        echo '<input name="password" class="form-control" type="password" id="password" autocomplete="current-password" placeholder="'.esc_attr__('Password','buscom').'">';
                                    echo'</div></div></div>';

                                    do_action( 'woocommerce_login_form' );

                                    echo '<div class="col-md-12">';
                                        echo '<div class="row">';
                                            echo '<label class="woocommerce-form__label woocommerce-form__label-for-checkbox woocommerce-form-login__rememberme">
                                                <input class="woocommerce-form__input woocommerce-form__input-checkbox" name="rememberme" type="checkbox" id="rememberme" value="forever" /> <span>'.esc_html__('Remember me', 'buscom').'</span>
                                            </label>';
                                            echo '<a title="Lost Password" href="'.esc_url( wp_lostpassword_url() ).'" class="lost-pass-link">'.esc_html__( 'Lost your password?', 'buscom' ).'</a>';
                                        echo '</div>';
                                    echo '</div>';

                                    do_action( 'woocommerce_login_form' );
                                    
                                    echo '<div class="col-md-12">';
                                        echo '<div class="row">';
                                            wp_nonce_field( 'woocommerce-login', 'woocommerce-login-nonce' );
                                            echo'<button type="submit" class="woocommerce-button button woocommerce-form-login__submit" name="login" value="'.esc_attr__( 'Log in', 'buscom' ).'">'.esc_html__( 'Log in', 'buscom' ).'</button>';
                                        echo '</div>';
                                    echo '</div>';
                                echo '</div>';
                                do_action( 'woocommerce_login_form_end' );
                            echo '</form>';
                        ?>
                        <!-- End Login Form -->
                    </div>

                    <?php
                        if ( get_option( 'woocommerce_enable_myaccount_registration' ) === 'yes' ) :
                    ?>
                    <div class="tab-pane fade" data-tab="register" data-tab="register" id="register" aria-labelledby="register-tab">
                        <!-- Register Form -->
                        <?php
                            echo '<!-- Register Form -->';
                            echo '<form method="post" class="woocommerce-form woocommerce-form-register register">';
                                do_action( 'woocommerce_register_form_start' );
                                if ( 'no' === get_option( 'woocommerce_registration_generate_username' ) ) {
                                    echo '<p class="form-row form-group">';
                                        $resgisterusername = ( ! empty( $_POST['username'] ) ) ? wp_unslash( $_POST['username'] ) : '';
                                        echo '<input name="username" value="'.esc_attr( $resgisterusername ).'" class="form-control border" type="text" placeholder="'.esc_attr__('User Name','buscom').'">';
                                    echo '</p>';
                                }
                                echo '<div class="login-custom">';


                                    echo '<div class="col-md-12"><div class="row"><div class="form-group">';
                                        $registeremail = ( ! empty( $_POST['email'] ) ) ? wp_unslash( $_POST['email'] ) : '';
                                         echo '<input name="email" value="'.esc_attr($registeremail).'" class="form-control" type="email" placeholder="'.esc_attr__('Email','buscom').'">';
                                    echo '</div></div></div>';

                                    echo '<div class="col-md-12"><div class="row"><div class="form-group">';
                                        $registername = ( ! empty( $_POST['username'] ) ) ? wp_unslash( $_POST['username'] ) : '';
                                         echo '<input name="text" value="'.esc_attr($registername).'" class="form-control" type="text" placeholder="'.esc_attr__('UserName','buscom').'">';
                                    echo '</div></div></div>';

                                    if ( 'no' === get_option( 'woocommerce_registration_generate_password' ) ){

                                        echo '<div class="col-md-12"><div class="row"><div class="form-group">';
                                            echo '<input name="password" class="form-control" type="password" placeholder="'.esc_attr__('Password','buscom').'">';
                                        echo '</div></div></div>';
                                    } else {
                                        echo '<p class="form-row form-group">';
                                            esc_html_e( 'A password will be sent to your email address.', 'buscom' );
                                        echo '</p>';
                                    }

                                    do_action( 'woocommerce_register_form' );

                                    echo '<div class="col-md-12"><div class="row">';
                                        echo wp_nonce_field( 'woocommerce-register', 'woocommerce-register-nonce' );
                                        echo '<button type="submit" value="'.esc_attr__( 'Register', 'buscom' ).'" name="register">'.esc_html__( 'Register', 'buscom' ).'</button>';
                                    echo '</div></div>';

                                echo '</div>';

                                do_action( 'woocommerce_register_form_end' );



                            echo '</form>';
                            echo '<!-- End Register Form -->';
                        ?>
                        <!-- End Register Form -->
                    </div>
                    <?php
                        endif;
                    ?>
                </div>
                <!-- End Tab Content -->
        </div>
</div>

<?php do_action( 'woocommerce_after_customer_login_form' ); ?>
