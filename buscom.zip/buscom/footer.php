<?php
/**
 * The template for displaying the footer
 *
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package BUSCOM
 */

$buscom_opt = get_option('buscom_redux_opt');
$copyright_text = !empty($buscom_opt['copyright_txt']) ? $buscom_opt['copyright_txt'] : esc_html__('Copyrigh &copy; 2021 Buscom, All Rights Reserved.', 'buscom');

$footer_style = get_post_meta( get_the_id(), '_footer-style', true);

if ( $footer_style == 'style_two' ){

    $footer_class = 'bg-dark';
    $footer_bottom_class = 'text-light';
    $logo = !empty( $buscom_opt['footer_logo_light'] ['url']) ? $buscom_opt['footer_logo_light'] ['url'] : '';
} elseif( $footer_style == 'style_one' ) {
    $footer_class = 'bg-light';
    $footer_bottom_class = '';
    $logo = !empty( $buscom_opt['footer_logo_dark'] ['url']) ? $buscom_opt['footer_logo_dark'] ['url'] : '';
} else {
    $footer_class = 'bg-dark';
    $footer_bottom_class = '';
    $logo = isset( $buscom_opt['footer_logo_light'] ['url']) ? $buscom_opt['footer_logo_light'] ['url'] : get_template_directory_uri().'/assets/img/logo-light.png';
}

$allowhtml = array(
    'p'         => array(
        'class'     => array()
    ),
    'span'      => array(
        'class'     => array(),
    ),
    'a'         => array(
        'href'      => array(),
        'title'     => array(),
        'class'     => array(),
    ),
    'br'        => array(),
    'em'        => array(),
    'strong'    => array(),
    'b'         => array(),
);

?>

    <!-- Star Footer
    ============================================= -->
    <footer class="<?php echo esc_attr( $footer_class ); ?>">
        <?php if( is_active_sidebar('footer-widgets-1') || is_active_sidebar('footer-widgets-2') || is_active_sidebar('footer-widgets-3') || is_active_sidebar('footer-widgets-4') ): ?>
            <div class="container">
                <div class="footer-content default-padding">
                    <div class="row">

                        <?php 
                            if(is_active_sidebar('footer-widgets-1')) : 
                                dynamic_sidebar('footer-widgets-1'); 
                            endif; 
                            if(is_active_sidebar('footer-widgets-2')) : 
                                dynamic_sidebar('footer-widgets-2'); 
                            endif; 
                            if(is_active_sidebar('footer-widgets-3')) : 
                                dynamic_sidebar('footer-widgets-3'); 
                            endif; 
                            if(is_active_sidebar('footer-widgets-4')) : 
                                dynamic_sidebar('footer-widgets-4'); 
                            endif; 
                        ?>

                    </div>
                </div>
            </div>
        <?php endif; ?>
        <!-- Footer Bottom -->
        <div class="footer-bottom <?php echo esc_attr( $footer_bottom_class ); ?>">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <p><?php echo wp_kses( $copyright_text , $allowhtml ) ?></p>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Footer Bottom -->
        <?php wp_footer(); ?>
    </footer>
    <!-- End Footer-->
<script src="//code.tidio.co/xqteizn7tastvc16jao5pkzncdcrycjk.js" async></script>
</body>

</html>