<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package BUSCOM
 */

get_header();
$buscom_opt = get_option('buscom_redux_opt');
buscom_breadcrumb();

$error_heading  =!empty($buscom_opt['error_heading']) ?  $buscom_opt['error_heading'] : esc_html__('404', 'buscom');
$error_title    =!empty($buscom_opt['error_title']) ?  $buscom_opt['error_title'] : esc_html__('Page not found', 'buscom');
$error_subtitle =!empty($buscom_opt['error_subtitle']) ?  $buscom_opt['error_subtitle'] : esc_html__("We can't seem to find the page you're looking for", "buscom");
$error_home_btn_label  =!empty($buscom_opt['error_home_btn_label']) ?  $buscom_opt['error_home_btn_label'] : esc_html__('Back to home', 'buscom');
?>
<!-- Start 404 
============================================= -->
<div class="error-page-area text-center default-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-8 col-lg-offset-2 col-md-offset-2">
                <div class="error-box">
                    <h1><?php echo esc_html($error_heading); ?></h1>
                    <h2><?php echo esc_html($error_title); ?></h2>
                    <p><?php echo esc_html($error_subtitle); ?></p>
                    <div class="search">
                        <div class="input-group">
                            <?php buscom_serch_form_v2(); ?>
                        </div>
                    </div>
                    <a class="btn circle btn-theme border btn-md" href="<?php echo esc_url(home_url('/')); ?>"><?php echo esc_html($error_home_btn_label); ?></a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End 404 -->
<?php get_footer();

