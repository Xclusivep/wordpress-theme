<?php
// Block direct access
if( !defined( 'ABSPATH' ) ){
    exit();
}

// buscom shop main content hook functions
if( !function_exists('buscom_shop_main_content_cb') ) {
    function buscom_shop_main_content_cb( ) {

        if( is_shop() || is_product_category() || is_product_tag() ) {
            echo '<div class="validtheme-shop-area validthemes-woocommerce-default default-padding">';
            if( class_exists('ReduxFramework') ) {
                $buscom_opt = get_option('buscom_redux_opt');
                $buscom_woo_product_col = $buscom_opt['buscom_woo_product_col'];
                if( $buscom_woo_product_col == '2' ) {
                    echo '<div class="container">';
                } elseif( $buscom_woo_product_col == '3' ) {
                    echo '<div class="container">';
                } elseif( $buscom_woo_product_col == '4' ) {
                    echo '<div class="container">';
                } elseif( $buscom_woo_product_col == '5' ) {
                    echo '<div class="buscom-container">';
                } elseif( $buscom_woo_product_col == '6' ) {
                    echo '<div class="buscom-container">';
                }
            } else {
                echo '<div class="container">';
            }
        } else {
            echo '<div class="validtheme-shop-single-area validthemes-woocommerce-default default-padding product-details">';
                echo '<div class="container">';
        }
            echo '<div class="row">';
    }
}

// buscom shop main content hook function
if( !function_exists('buscom_shop_main_content_end_cb') ) {
    function buscom_shop_main_content_end_cb( ) {
            echo '</div>';
        echo '</div>';
    echo '</div>';
    }
}


// shop column start hook function
if( !function_exists('buscom_shop_col_start_cb') ) {
    function buscom_shop_col_start_cb( ) {
        if( class_exists('ReduxFramework') ) {
            $buscom_opt = get_option('buscom_redux_opt');
            if( class_exists('buscom') && is_shop() ) {
                $buscom_woo_shoppage_sidebar = $buscom_opt['buscom_woo_shoppage_sidebar'];
                if( $buscom_woo_shoppage_sidebar == '2' && is_active_sidebar('buscom-woo-sidebar') ) {
                    echo '<div class="col-lg-8 order-last">';
                } elseif( $buscom_woo_shoppage_sidebar == '3' && is_active_sidebar('buscom-woo-sidebar') ) {
                    echo '<div class="col-lg-8">';
                } else {
                    echo '<div class="col-lg-12">';
                }
            } else {
                echo '<div class="col-lg-12">';
            }
        } else {
            if( class_exists('buscom') && is_shop() ) {
                if( is_active_sidebar('buscom-woo-sidebar') ) {
                    echo '<div class="col-lg-8">';
                } else {
                    echo '<div class="col-lg-12">';
                }
            } else {
                echo '<div class="col-lg-12">';
            }
        }

    }
}

// shop column end hook function
if( !function_exists('buscom_shop_col_end_cb') ) {
    function buscom_shop_col_end_cb( ) {
        echo '</div>';
    }
}

// buscom woocommerce pagination hook function
if( ! function_exists('buscom_woocommerce_pagination') ) {
    function buscom_woocommerce_pagination( ) {
        echo '<nav class="woocommerce-pagination">';
            buscom_woo_pagination();  
        echo '</nav>';         
    }
}


// buscom woocommerce get sidebar hook function
if( ! function_exists('buscom_woocommerce_get_sidebar') ) {
    function buscom_woocommerce_get_sidebar( ) {
        if( class_exists('ReduxFramework') ) {
            $buscom_opt = get_option('buscom_redux_opt');
            $buscom_woo_shoppage_sidebar = $buscom_opt['buscom_woo_shoppage_sidebar'];
        } else {
            if( is_active_sidebar('buscom-woo-sidebar') ) {
                $buscom_woo_shoppage_sidebar = '2';
            } else {
                $buscom_woo_shoppage_sidebar = '1';
            }
        }

        if( is_shop() ) {

            if( $buscom_woo_shoppage_sidebar != '1' ) {
                echo '<div class="col-lg-4">';
                dynamic_sidebar( 'buscom-woo-sidebar' );
                echo '</div>';
            }
        }
    }
}

// woocommerce filter wrapper hook function
if( ! function_exists('buscom_woocommerce_filter_wrapper') ) {
    function buscom_woocommerce_filter_wrapper( ) {
        echo '<div class="shop-listing-contentes">';
            echo '<div class="row item-flex center">';
                echo '<div class="col-md-7">';
                    echo '<div class="content">';
                        echo '<!-- Tab Nav -->';
                        echo '<ul class="nav nav-pills">';
                            echo '<li class="active">';
                                echo '<a data-toggle="tab" href="#grid-view" aria-expanded="true"><i class="ti-layout-grid2"></i></a>';
                            echo '</li>';
                            echo '<li><a data-toggle="tab" href="#list-view" aria-expanded="false"><i class="ti-view-list-alt"></i></a></li>';
                        echo '</ul>';
                        echo woocommerce_catalog_ordering();
                        echo '<!-- End Tab Nav -->';
                    echo '</div>';
                echo '</div>';
                echo '<div class="col-md-5 text-right">';
                echo woocommerce_result_count();
                echo '</div>';
            echo '</div>';
       echo '</div>';
    }
}


// woocommerce tab content wrapper start hook function
if( ! function_exists('buscom_woocommerce_tab_content_wrapper_start') ) {
    function buscom_woocommerce_tab_content_wrapper_start( ) {
        echo '<!-- Tab Content -->';
        echo '<div class="tab-content tab-content-info">';
    }
}

// woocommerce tab content wrapper start hook function
if( ! function_exists('buscom_woocommerce_tab_content_wrapper_end') ) {
    function buscom_woocommerce_tab_content_wrapper_end( ) {
        echo '</div>';
        echo '<!-- End Tab Content -->';
    }
}
// buscom grid tab content hook function
if( !function_exists('buscom_grid_tab_content_cb') ) {
    function buscom_grid_tab_content_cb( ) {
        echo '<!-- Grid -->';
            echo '<div id="grid-view" class="tab-pane fade active in">';
                echo '<div class="shop-grid-area">';
                   woocommerce_product_loop_start();
                    if( class_exists('ReduxFramework') ) {
                        $buscom_opt = get_option('buscom_redux_opt');
                        $buscom_woo_product_col = $buscom_opt['buscom_woo_product_col'];
                        if( $buscom_woo_product_col == '2' ) {
                            $buscom_woo_product_col_val = '2';
                        } elseif( $buscom_woo_product_col == '3' ) {
                            $buscom_woo_product_col_val = '3';
                        } elseif( $buscom_woo_product_col == '4' ) {
                            $buscom_woo_product_col_val = '4';
                        }elseif( $buscom_woo_product_col == '5' ) {
                            $buscom_woo_product_col_val = '5';
                        } elseif( $buscom_woo_product_col == '6' ) {
                            $buscom_woo_product_col_val = '6';
                        }
                    } else {
                        $buscom_woo_product_col_val = '4';
                    }

                    echo '<ul class="vt-products columns-'.esc_attr( $buscom_woo_product_col_val ).'">';

                    if ( wc_get_loop_prop( 'total' ) ) {
                        while ( have_posts() ) {
                            the_post();

                                /**
                                 * Hook: woocommerce_shop_loop.
                                 */
                                do_action( 'woocommerce_shop_loop' );

                                wc_get_template_part( 'content', 'product' );
                        }
                        wp_reset_postdata();
                    }
                    woocommerce_product_loop_end();
                echo '</div>';
            echo '</div>';
        echo '<!-- End Grid -->';
    }
}

// buscom list tab content hook function
if( !function_exists('buscom_list_tab_content_cb') ) {
    function buscom_list_tab_content_cb( ) {
        echo '<!-- List -->';
        echo '<div id="list-view" class="tab-pane fade">';
            echo '<ul class="vt-products">';
                woocommerce_product_loop_start();

                if ( wc_get_loop_prop( 'total' ) ) {
                    while ( have_posts() ) {
                        the_post();
                            /**
                             * Hook: woocommerce_shop_loop.
                             */
                            do_action( 'woocommerce_shop_loop' );

                            wc_get_template_part( 'content-horizontal', 'product' );
                    }
                    wp_reset_postdata();
                }
                woocommerce_product_loop_end();
            echo '</ul>';
        echo '</div>';
        echo '<!-- End List -->';
    }
}

// woocommerce tab content wrapper start hook function
if( ! function_exists('buscom_woocommerce_shop_product_wrapper_end') ) {
    function buscom_woocommerce_shop_product_wrapper_end( ) {
        echo '</div>';
        echo '<!-- End Tab Content -->';
    }
}

// buscom loop product thumbnail hook function
if( !function_exists('buscom_loop_product_thumbnail') ) {
    function buscom_loop_product_thumbnail( ) {
        global $product;
        echo '<!-- Single product -->';
        echo '<li class="shop-product">';
            echo '<div class="product-contents">';
                echo '<div class="product-image">';
                    if( $product->is_type('simple') || $product->is_type('external') || $product->is_type('grouped') ) {
      
                        $regular_price  = get_post_meta( $product->get_id(), '_regular_price', true ); 
                        $sale_price     = get_post_meta( $product->get_id(), '_sale_price', true );
                     
                         if( !empty($sale_price) ) {
                  
                            $amount_saved = $regular_price - $sale_price;
                            $currency_symbol = get_woocommerce_currency_symbol();
                            $percentage = round( ( ( $regular_price - $sale_price ) / $regular_price ) * 100 );

                            echo "<span class='onsale'>" . number_format($percentage,0, '', '') .esc_html__('% Off', 'buscom'). "</span>";
                        }
                    }
                    echo '<a href="'.esc_url( get_permalink() ).'">';
                        echo '<img src="'.esc_url( get_the_post_thumbnail_url() ).'" alt="'.esc_attr( buscom_img_default_alt(  get_the_post_thumbnail_url() )).'">';
                    echo '</a>';
                    echo '<div class="shop-action">';
                        echo '<ul>';
                           echo '<li class="wishlist">';
                                if( class_exists( 'TInvWL_Admin_TInvWL' ) ){
                                    echo do_shortcode( '[ti_wishlists_addtowishlist]' );
                                }
                            echo '</li>';
                            echo '<li class="compare">';
                            if( class_exists( 'WPCleverWoosc' ) ){
                                echo do_shortcode('[woosc]');
                            }
                            echo '</li>';
                            if( class_exists( 'WPCleverWoosq' ) ){
                                echo do_shortcode('[woosq]');
                            }
                        echo '</ul>';
                    echo '</div>';
                echo '</div>';
                echo '<div class="product-caption">';
                    echo '<div class="tags">';
                        echo '<ul>';
                        echo wc_get_product_tag_list($product->get_id(), ',', '<li>', '</li>'); 
                        echo '</ul>';
                    echo '</div>';
                    echo '<h4 class="product-title"><a href="'.esc_url( get_permalink() ).'">'.esc_html( get_the_title() ).'</a></h4>';

                    $review_count = $product->get_review_count();
                    if ( $review_count > 0 ) : 
                        echo '<div class="review-count">';
                            echo '<div class="rating">';
                               echo woocommerce_template_loop_rating();
                            echo '</div>';
                        echo '</div>';
                    endif;
                    echo '<div class="price">';
                        echo woocommerce_template_loop_price();
                    echo '</div>';
                    echo woocommerce_template_loop_add_to_cart();
               echo ' </div>';
            echo '</div>';
        echo '</li>';
        echo '<!-- Single product -->';
    }
}

// buscom loop horizontal product thumbnail hook function
if( !function_exists('buscom_loop_horiontal_product_thumbnail') ) {
    function buscom_loop_horiontal_product_thumbnail( ) {
        global $product;

        echo '<li class="product">';
            echo '<div class="product-contents">';
                echo '<div class="row">';
                    echo '<div class="col-md-5">';
                        if( has_post_thumbnail() ){
                            echo '<div class="product-image">';
                                if( $product->is_type('simple') || $product->is_type('external') || $product->is_type('grouped') ) {
      
                                    $regular_price  = get_post_meta( $product->get_id(), '_regular_price', true ); 
                                    $sale_price     = get_post_meta( $product->get_id(), '_sale_price', true );
                                 
                                     if( !empty($sale_price) ) {
                              
                                        $amount_saved = $regular_price - $sale_price;
                                        $currency_symbol = get_woocommerce_currency_symbol();
                                        $percentage = round( ( ( $regular_price - $sale_price ) / $regular_price ) * 100 );

                                        echo "<span class='onsale'>" . number_format($percentage,0, '', '') .esc_html__('% Off', 'buscom'). "</span>";
                                    }
                                }
                                echo '<a href="'.esc_url( get_permalink() ).'">';
                                    echo '<img src="'.esc_url( get_the_post_thumbnail_url() ).'" alt="'.esc_attr( buscom_img_default_alt(  get_the_post_thumbnail_url() )).'"></a>';
                                echo '<div class="shop-action">';
                                    echo '<ul>';
                                        echo '<li class="wishlist">';
                                            if( class_exists( 'TInvWL_Admin_TInvWL' ) ){
                                                echo do_shortcode( '[ti_wishlists_addtowishlist]' );
                                            }
                                        echo '</li>';
                                        echo '<li class="compare">';
                                        if( class_exists( 'WPCleverWoosc' ) ){
                                            echo do_shortcode('[woosc]');
                                        }
                                        echo '</li>';
                                        // Quick View Button
                                        if( class_exists( 'WPCleverWoosq' ) ){
                                            echo do_shortcode('[woosq]');
                                        }
                                    echo '</ul>';
                                echo '</div>';
                            echo '</div>';
                        }
                    echo '</div>';
                    echo '<div class="col-md-7">';
                        echo '<div class="product-caption">';
                            echo '<div class="tags">';
                                echo '<ul>';
                                echo wc_get_product_tag_list($product->get_id(), ',', '<li>', '</li>'); 
                                echo '</ul>';
                            echo '</div>';
                            echo '<h4 class="product-title"><a href="'.esc_url( get_permalink() ).'">'.esc_html( get_the_title() ).'</a></h4>';
                            $review_count = $product->get_review_count();
                                if ( $review_count > 0 ) : 
                                    echo '<div class="review-count">';
                                        echo woocommerce_template_loop_rating();
                                    echo '</div>';
                                endif;
                            echo '<div class="price">';
                                echo woocommerce_template_loop_price();
                            echo '</div>';
                            woocommerce_template_single_excerpt();
                            echo woocommerce_template_loop_add_to_cart();;
                        echo '</div>';
                    echo '</div>';
                echo '</div>';
            echo '</div>';
        echo '</li>';
    }
}

// before single product summary hook
if( ! function_exists('buscom_woocommerce_before_single_product_summary') ) {
    function buscom_woocommerce_before_single_product_summary( ) {
        global $post,$product;
        $attachments = $product->get_gallery_image_ids();
        echo '<div class="row">';
        echo '<div class="col-md-6">';
            echo '<div class="product-thumb">';
                if( $attachments ){
                    
                    echo '<div class="carousel slide" data-ride="carousel" id="timeline-carousel">';

                        echo '<div class="carousel-inner item-box">';

                            $x = 0;
                            foreach( $attachments as $single_slide_image ){
                                $x++;
                                $active_class = ($x == 1) ? 'active' : '';

                                echo '<div class="item product-item '.esc_attr( $active_class ).'">';
                                    echo '<a href="'.esc_url( wp_get_attachment_image_url( $single_slide_image, 'medium' ) ).'" class="item popup-gallery">';
                                        echo '<img src="'.esc_url( wp_get_attachment_image_url( $single_slide_image, 'full' ) ).'" alt="Thumb">';
                                    echo '</a>';

                                    if( $product->is_type('simple') || $product->is_type('external') || $product->is_type('grouped') ) {
      
                                        $regular_price  = get_post_meta( $product->get_id(), '_regular_price', true ); 
                                        $sale_price     = get_post_meta( $product->get_id(), '_sale_price', true );
                                     
                                         if( !empty($sale_price) ) {
                                  
                                            $amount_saved = $regular_price - $sale_price;
                                            $currency_symbol = get_woocommerce_currency_symbol();
                                            $percentage = round( ( ( $regular_price - $sale_price ) / $regular_price ) * 100 );

                                            echo "<span class='onsale theme'>-" . number_format($percentage,0, '', '') . "%</span>";
                                        }
                                    }
                                echo '</div>';
                            }

                            
                        echo '</div>';

                        echo '<!-- Carousel Indicators -->';
                        echo '<ol class="carousel-indicators">';
                            echo '<div class="product-gallery-carousel owl-carousel owl-theme">';

                                $x = 0;
                                foreach( $attachments as $single_slide_image ){
                                    
                                    $active2_class = ($x !== 1) ? 'active' : '';
                                    echo '<li data-target="#timeline-carousel" data-slide-to="'.esc_attr( $x ).'" class="'.esc_attr( $active2_class ).'">';
                                        echo '<img src="'.esc_url( wp_get_attachment_image_url( $single_slide_image, 'full' ) ).'" alt="">';
                                    echo '</li>';
                                    $x++;
                                }
                            echo '</div>';
                        echo '</ol>';

                        
                        echo '<!-- End Carousel Content -->';   
                    echo '</div>';
                }elseif( has_post_thumbnail() ){
                    echo '<div class="item-box">';
                        echo '<div class="product-item">';

                            echo '<a href="'.esc_url( get_the_post_thumbnail_url() ).'" class="item popup-gallery">';
                                echo '<img src="'.esc_url( get_the_post_thumbnail_url() ).'" alt="Thumb">';
                            echo '</a>';
                            if( $product->is_type('simple') || $product->is_type('external') || $product->is_type('grouped') ) {

                                $regular_price  = get_post_meta( $product->get_id(), '_regular_price', true ); 
                                $sale_price     = get_post_meta( $product->get_id(), '_sale_price', true );
                             
                                 if( !empty($sale_price) ) {
                          
                                    $amount_saved = $regular_price - $sale_price;
                                    $currency_symbol = get_woocommerce_currency_symbol();
                                    $percentage = round( ( ( $regular_price - $sale_price ) / $regular_price ) * 100 );

                                    echo "<span class='onsale theme'>-" . number_format($percentage,0, '', '') . "%</span>";
                                }
                            }
                        echo '</div>';
                    echo '</div>';
                }
            echo '</div>';
        echo '</div>';
    }
}

// woocommerce single products tag and ratting hook function
if( ! function_exists('buscom_woocommerce_template_single_rating_and_tags') ) {
    function buscom_woocommerce_template_single_rating_and_tags( ) {
        global $product;
        echo '<div class="summary-top-box">';
            echo '<div class="tags">';
                echo wc_get_product_tag_list($product->get_id(), ',', '', ''); 
            echo '</div>';
            $review_count = $product->get_review_count();
            if ( $review_count > 0 ) : 
                echo '<div class="review-count">';
                    echo '<div class="rating">';
                        echo woocommerce_template_loop_rating();
                    echo '</div>';
                echo '</div>';
            endif;
        echo '</div>';
    }
}

// woocommerce single products title
if( ! function_exists('buscom_woocommerce_single_product_title') ) {
    function buscom_woocommerce_single_product_title( ) {
        echo '<h2 class="product-title">'.esc_html( get_the_title() ).'</h2>';
    }
}
// woocommerce single products price
if( ! function_exists('buscom_woocommerce_single_product_price_rating') ) {
    function buscom_woocommerce_single_product_price_rating( ) {
        echo '<div class="price">';
            // Product Price
            echo woocommerce_template_loop_price();
        echo '</div>';

    }
}

// single product availability hook function
if( !function_exists('buscom_woocommerce_single_product_availability') ) {
    function buscom_woocommerce_single_product_availability( ) {
        global $product;
        $availability = $product->get_availability();

        if( $availability['class'] != 'out-of-stock' ) {
            if( $product->get_stock_quantity() ){
                echo '<div class="product-stock buscom-in-stock-qty">';
                    echo '<div class="product-quantity">'.esc_html( $product->get_stock_quantity() ).' '.esc_html__( ' items availabe', 'buscom' ).'</div>';
                echo '</div>';
            }else{
                echo '<div class="product-stock buscom-in-stock">';
                echo '<span>'.esc_html__( 'In Stock', 'buscom' ).'</span>';
            echo '</div>';
            }
            
        }else{
            echo '<div class="product-stock buscom-out-of-stock">';
                echo '<span>'.esc_html__( 'Out Of Stock', 'buscom' ).'</span>';
            echo '</div>';
        }
    }
}

// single product excerpt hook function
if( !function_exists('buscom_woocommerce_single_product_excerpt') ) {
    function buscom_woocommerce_single_product_excerpt( ) {
        woocommerce_template_single_excerpt();
    }
}

add_filter( 'woocommerce_short_description', 'woocommerce_new_short_description', 10, 2 );
function woocommerce_new_short_description( $short_description ){
    $allowhtml = array(
        'p'         => array(
            'class'     => array()
        ),
        'span'      => array(
            'class'     => array(),
        ),
        'a'         => array(
            'href'      => array(),
            'title'     => array()
        ),
        'br'        => array(),
        'em'        => array(),
        'strong'    => array(),
        'b'         => array(),
        'ul'        => array(
            'class'     => array(),
        ),
        'li'        => array(
            'class'     => array(),
        ),
    );
    echo '<div class="single-product-desc">';
        echo wp_kses( $short_description, $allowhtml );
    echo '</div>';
}

// single product add to cart fuunction
if( !function_exists('buscom_woocommerce_single_add_to_cart_button') ) {
    function buscom_woocommerce_single_add_to_cart_button( ) {
        woocommerce_template_single_add_to_cart();    
    }
}


//add meta field in product 
if( !function_exists('woocom_shipping_product_delivery_duration') ) {
    function woocom_shipping_product_delivery_duration() {
    global $woocommerce, $post;
        // shipping date max or min doration
        
        woocommerce_wp_text_input( 
            array( 
                'id'                => '_buscom_shipping_durations', 
                'label'             => __( 'Dalivery Time (in days)', 'buscom' ), 
                'desc_tip'          => 'true',
                'description'       => __( 'How many days you need to deliver this product?', 'buscom' ),
            )
        );
        woocommerce_wp_text_input( 
            array( 
              'id'              => '_delivery_text', 
              'label'           => __( 'Delivery Text', 'vecuro' ), 
              'placeholder'     => __('Speedy and reliable parcel delivery!', 'buscom'),
              'desc_tip'        => 'true',
              'description' => __( 'This text will shown on sigle product page after the delivery date text', 'vecuro' ) 
            )
        );
    }
}

if( !function_exists('woocom_save_general_proddata_custom_field') ) {

    /** Hook callback function to save custom fields information */
    function woocom_save_general_proddata_custom_field( $post_id ) {

        // days
        $buscom_shipping_durations = $_POST['_buscom_shipping_durations'];
        if( ! empty( $buscom_shipping_durations ) ) {
            update_post_meta( $post_id, '_buscom_shipping_durations', esc_attr( $buscom_shipping_durations ) );
        }
        // text for showing adter the duration 
        $day_duration_text = $_POST['_delivery_text'];
        if( ! empty( $day_duration_text ) ) {
            update_post_meta( $post_id, '_delivery_text', esc_attr( $day_duration_text ) );
        }
    }
}

// estimate delivery
if( !function_exists('buscom_woocommerce_product_estimate_delivary') ) {
    function buscom_woocommerce_product_estimate_delivary( ) {
        global $product;
        $delivery_durations = get_post_meta( get_the_ID(), '_buscom_shipping_durations', true );
        $day_duration_text = get_post_meta( get_the_ID(), '_delivery_text', true );

        $constant_days = 2;
        $conditional_day = 1;

        if(!empty($delivery_durations)){
            
            echo '<div class="product-estimate-delivary"><i class="fas fa-box-open"></i>';

                echo '<strong> '.esc_html( $delivery_durations ).''.esc_html__(' day Delivery', 'buscom').'</strong>';
                $note = !empty($day_duration_text) ? $$day_duration_text : __( 'Speedy and reliable parcel delivery!', 'vecuro' );
                echo '<span>'.esc_html($note).'</span>';
            echo '</div>';
        }   
    }
}

// single product ,eta hook function
if( !function_exists('buscom_woocommerce_single_meta') ) {
    function buscom_woocommerce_single_meta( ) {
        global $product;

        echo '<div class="product-meta">';
            if( ! empty( $product->get_sku() ) ){
                echo '<span class="sku">';
                    echo '<strong>'.esc_html__( 'SKU:', 'buscom' ).'</strong> '.$product->get_sku().'';
                echo '</span>';
            }
            echo wc_get_product_category_list( $product->get_id(), ', ', '<span class="posted_in">' . _n( 'Category:', 'Categories:', count( $product->get_category_ids() ), 'buscom' ) . ' ', '</span>' );
        echo '</div>';
    }
}
// Adding a custom Meta container to admin products pages
add_action( 'add_meta_boxes', 'create_custom_meta_box' );
if ( ! function_exists( 'create_custom_meta_box' ) )
{
    function create_custom_meta_box()
    {
        add_meta_box(
            'custom_product_meta_box',
            __( 'Product spacification <em>(optional)</em>', 'buscom' ),
            'add_custom_content_meta_box',
            'product',
            'normal',
            'default'
        );
    }
}
//  Custom metabox content in admin product pages
if ( ! function_exists( 'add_custom_content_meta_box' ) ){
    function add_custom_content_meta_box( $post ){
        $prefix = '_bhww_'; // global $prefix;
        $ingredients = get_post_meta($post->ID, $prefix.'ingredients_wysiwyg', true) ? get_post_meta($post->ID, $prefix.'ingredients_wysiwyg', true) : '';
        $args['textarea_rows'] = 6;
        echo '<p>'.__( 'You may write your product spacification here if you want to show this on single product tablist', 'buscom' ).'</p>';
        wp_editor( $ingredients, 'ingredients_wysiwyg', $args );
        echo '<input type="hidden" name="custom_product_field_nonce" value="' . wp_create_nonce() . '">';
    }
}
//Save the data of the Meta field
add_action( 'save_post', 'save_custom_content_meta_box', 10, 1 );
if ( ! function_exists( 'save_custom_content_meta_box' ) )
{
    function save_custom_content_meta_box( $post_id ) {
        $prefix = '_bhww_'; // global $prefix;
        if ( ! isset( $_POST[ 'custom_product_field_nonce' ] ) ) {
            return $post_id;
        }
        $nonce = $_REQUEST[ 'custom_product_field_nonce' ];
        if ( ! wp_verify_nonce( $nonce ) ) {
            return $post_id;
        }
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return $post_id;
        }
        if ( 'product' == $_POST[ 'post_type' ] ){
            if ( ! current_user_can( 'edit_product', $post_id ) )
                return $post_id;
        } else {
            if ( ! current_user_can( 'edit_post', $post_id ) )
                return $post_id;
        }
        update_post_meta( $post_id, $prefix.'ingredients_wysiwyg', wp_kses_post($_POST[ 'ingredients_wysiwyg' ]) );
    }
}
// Create custom tabs in product single pages
add_filter( 'woocommerce_product_tabs', 'custom_product_tabs' );
function custom_product_tabs( $tabs ) {
    global $post;
    $product_ingredients = get_post_meta( $post->ID, '_bhww_ingredients_wysiwyg', true );
    if ( ! empty( $product_ingredients ) )
        $tabs['ingredients_tab'] = array(
            'title'    => __( 'Spacification', 'buscom' ),
            'priority' => 45,
            'callback' => 'ingredients_product_tab_content'
        );
    return $tabs;
}
// Add content to custom tab in product single pages
function ingredients_product_tab_content() {
    global $post;
    $product_ingredients = get_post_meta( $post->ID, '_bhww_ingredients_wysiwyg', true );
    if ( ! empty( $product_ingredients ) ) {
        echo apply_filters( 'the_content', $product_ingredients );
    }
}

// reviewer meta hook function
if( !function_exists('buscom_woocommerce_reviewer_meta') ) {
    function buscom_woocommerce_reviewer_meta( $comment ){
        $verified = wc_review_is_from_verified_owner( $comment->comment_ID );
        if ( '0' === $comment->comment_approved ) { ?>
            <em class="woocommerce-review__awaiting-approval">
                <?php esc_html_e( 'Your review is awaiting approval', 'buscom' ); ?>
            </em>

        <?php } else {
            woocommerce_review_display_rating(); ?>
            <div class="review-date"><time class="woocommerce-review__published-date" datetime="<?php echo esc_attr( get_comment_date( 'c' ) ); ?>"> <?php printf( esc_html__('%1$s', 'buscom'), get_comment_date(wc_date_format()) ); ?> </time></div>
            <div class="review-authro"><h5><?php echo ucwords( get_comment_author() ); ?></h5></div>
            <?php
            if ( 'yes' === get_option( 'woocommerce_review_rating_verification_label' ) && $verified ) {
                echo '<em class="woocommerce-review__verified verified">(' . esc_attr__( 'verified owner', 'buscom' ) . ')</em> ';
            }
        }
    }
}

remove_action( 'woocommerce_widget_shopping_cart_buttons', 'woocommerce_widget_shopping_cart_button_view_cart', 10 );
remove_action( 'woocommerce_widget_shopping_cart_buttons', 'woocommerce_widget_shopping_cart_proceed_to_checkout', 20 );

function my_woocommerce_widget_shopping_cart_button_view_cart() {
    echo '<a href="' . esc_url( wc_get_cart_url() ) . '" class="btn btn-gray border">' . esc_html__( 'View cart', 'buscom' ) . '</a>';
}
function my_woocommerce_widget_shopping_cart_proceed_to_checkout() {
    echo '<a href="' . esc_url( wc_get_checkout_url() ) . '" class="btn btn-theme effect">' . esc_html__( 'Checkout', 'buscom' ) . '</a>';
}
add_action( 'woocommerce_widget_shopping_cart_buttons', 'my_woocommerce_widget_shopping_cart_button_view_cart', 10 );
add_action( 'woocommerce_widget_shopping_cart_buttons', 'my_woocommerce_widget_shopping_cart_proceed_to_checkout', 20 );


// add to cart button
function woocommerce_template_loop_add_to_cart( $args = array() ) {
    global $product;

        if ( $product ) {
            $defaults = array(
                'quantity'   => 1,
                'class'      => implode(
                    ' ',
                    array_filter(
                        array(
                            'cart-button icon-btn btn',
                            'product_type_' . $product->get_type(),
                            $product->is_purchasable() && $product->is_in_stock() ? 'add_to_cart_button' : '',
                            $product->supports( 'ajax_add_to_cart' ) && $product->is_purchasable() && $product->is_in_stock() ? 'ajax_add_to_cart' : '',
                        )
                    )
                ),
                'attributes' => array(
                    'data-product_id'  => $product->get_id(),
                    'data-product_sku' => $product->get_sku(),
                    'aria-label'       => $product->add_to_cart_description(),
                    'rel'              => 'nofollow',
                    'title'            => 'add to cart',
                ),
            );

            $args = wp_parse_args( $args, $defaults );

            if ( isset( $args['attributes']['aria-label'] ) ) {
                $args['attributes']['aria-label'] = wp_strip_all_tags( $args['attributes']['aria-label'] );
            }
        }

        echo sprintf( '<a href="%s" data-quantity="%s" class="%s" %s>%s</a>',
            esc_url( $product->add_to_cart_url() ),
            esc_attr( isset( $args['quantity'] ) ? $args['quantity'] : 1 ),
            esc_attr( isset( $args['class'] ) ? $args['class'] : 'cart-button icon-btn btn' ),
            isset( $args['attributes'] ) ? wc_implode_html_attributes( $args['attributes'] ) : '',
            '<i class="ti-shopping-cart"></i><span>'.esc_html__('Add to cart', 'buscom').'</span>'
        );
}

add_filter( 'woosq_button_html', 'buscom_woosq_button_html', 10, 2 );
function buscom_woosq_button_html( $output , $prodid ) {
    return $output = '<li class="quick-view"><a href="#" class="icon-btn woosq-btn woosq-btn-' . esc_attr( $prodid ) . ' ' . get_option( 'woosq_button_class' ) . '" data-id="' . esc_attr( $prodid ) . '" data-effect="mfp-3d-unfold"><span>'.esc_html__('Quick view', 'buscom').'</span></a>';
}

// product compare button remove
add_filter( 'filter_woosc_button_archive', function() {
    return '0';
} );
add_filter( 'filter_woosc_button_single', function() {
    return '0';
} );

add_filter( 'woosc_button_html', 'buscom_woosc_button_html', 10, 2 );
function buscom_woosc_button_html( $output , $prodid ) {
    return $output = '<a href="#" class="woosc-btn woosc-btn-' . esc_attr( $prodid ) . ' ' . get_option( '_woosc_button_class' ) . '" data-id="' . esc_attr( $prodid ) . '"><span>'.esc_html__('Compare ', 'buscom').'</span></a>';
}
add_filter( 'woocommerce_product_get_rating_html', function ( $html, $rating, $count ) {
    global $product;
    if ( $html &&  $product) {
        $html .= sprintf( '<div class="buscom-product-rating-count"><a href="'.get_permalink().'#reviews" class="woocommerce-review-link" rel="nofollow">(%s '.esc_html__('Review', 'buscom').')</a></div>', $product->get_rating_count() );
    }

    return $html;
}, 10, 3 );

remove_action( 'woosq_product_summary', 'woocommerce_template_single_rating', 10 );
add_action( 'woosq_product_summary', 'buscom_woosq_template_single_rating', 10 );

function buscom_woosq_template_single_rating() {
    global $product;
    $review_count = $product->get_review_count();
    if ( $review_count > 0 ) : 
        echo '<div class="review-count">';
            echo '<div class="rating">';
                echo woocommerce_template_loop_rating();
            echo '</div>';
        echo '</div>';
    endif;
}

remove_action( 'woosq_product_summary', 'woocommerce_template_single_meta', 30 );
add_action( 'woosq_product_summary', 'buscom_woocommerce_single_meta', 30 );

