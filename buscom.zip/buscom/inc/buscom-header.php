<?php
/*
Buscom own hook
 */
if(!function_exists('buscom_topbar')) {
	function buscom_topbar(){
		$buscom_opt = get_option('buscom_redux_opt');
		$topbar_position = get_post_meta( get_the_id(), '_is-topbar', true);
		$topbar_style = get_post_meta( get_the_id(), '_topbar-style', true);
		$view_layout 	= get_post_meta( get_the_id(), '_page-style', true);

		if( $view_layout == 'style_one' ){
    		$logo = isset( $buscom_opt['logo_dark'] ['url']) ? $buscom_opt['logo_dark'] ['url'] : ''; 
    	}else{
    		$logo = isset( $buscom_opt['logo_light'] ['url']) ? $buscom_opt['logo_light'] ['url'] : '';
    	}

		if ( $topbar_position == 'show' ) {
	        if ( $topbar_style == 'style_one' ) {?>
				<div class="top-bar-area">
					<div class="container">
						<div class="row">
						<?php
						if (!empty( $logo )) :?>
							<div class="col-md-3 logo">
								<a href="<?php echo esc_url( home_url()); ?>">
									<img src="<?php echo esc_url($logo); ?>" class="logo" alt="<?php esc_attr_e( 'Logo', 'buscom' );?>">
								</a>
							</div>
						<?php endif; ?>
							<div class="col-md-9 address-info text-right">
								<div class="info box">
									<?php buscom_informations(); ?>
								</div>
							</div>
						</div>
					</div>
				</div>
	    	<?php	
	    	} else { ?>
				<div class="top-bar-area bg-dark text-light">
					<div class="container">
						<div class="row">
							<div class="col-md-8 address-info text-left">
								<div class="info box">
									<?php buscom_informations(); ?>
								</div>
							</div>
							<div class="col-md-4 social text-right">
								<?php buscom_social_links(); ?>
							</div>
						</div>
					</div>
				</div>
			<?php
	    	}
	    }
	}
}

if(!function_exists('buscom_main_menu')){
	function buscom_main_menu(){

		$buscom_opt 	= get_option('buscom_redux_opt');
		$header_menu 	= get_post_meta( get_the_id(), '_header-menu-style', true);
		$view_layout 	= get_post_meta( get_the_id(), '_page-style', true);
		$side_menu 		= isset( $buscom_opt['sidemenu_position']) ? $buscom_opt['sidemenu_position'] : '';

		if( $view_layout == 'style_one' ){
    		$logo = isset( $buscom_opt['logo_dark'] ['url']) ? $buscom_opt['logo_dark'] ['url'] : ''; 
    	}else{
    		$logo = isset( $buscom_opt['logo_light'] ['url']) ? $buscom_opt['logo_light'] ['url'] : '';
    	}

    	if ( $header_menu == 'style_one' ) { ?>
		    <header id="home">
		        <!-- Start Navigation -->
		        <nav class="navbar navbar-default attr-border active-border logo-less small-pad navbar-sticky bootsnav">
		            <!-- Start Top Search -->
		            <div class="top-search">
		            	<div class="container">
                    		<div class="input-group">
		                        <?php buscom_serch_form(); ?>
		                    </div>
		                </div>
		            </div>
		            <!-- End Top Search -->

		            <div class="container">

		                <!-- Start Atribute Navigation -->
		                <div class="attr-nav">
		                    <ul>
		                        <li class="search"><a href="#"><i class="fas fa-search"></i></a></li>
		                        <?php
		                        if ( class_exists( 'WooCommerce' ) ) { ?>
		                        <li class="login"><a href="<?php echo get_permalink( wc_get_page_id( 'myaccount' ) ); ?>"><i class="fas fa-user"></i></a></li>
		                        
		                    	<?php } ?>
		                    </ul>

		                </div>        
		                <!-- End Atribute Navigation -->
		                 <!-- Start Header Navigation -->
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                                <i class="fa fa-bars"></i>
                            </button>
							<a class="navbar-brand" href="<?php echo esc_url( home_url()); ?>">
								<img src="<?php echo esc_url($logo); ?>" class="logo" alt="<?php esc_attr_e('Logo', 'buscom' ); ?>">
							</a>
                        </div>
                        <!-- End Header Navigation -->
		                <!-- Collect the nav links, forms, and other content for toggling -->
		                <div class="collapse navbar-collapse" id="navbar-menu">
		                    <?php
								wp_nav_menu( array(
									'theme_location'  => 'primary',
									'container'       => 'ul',
									'menu_class'      => 'nav navbar-nav navbar-left',
									'fallback_cb'     => 'Buscom_Bootstrap_Navwalker::fallback',
									'items_wrap'      => '<ul data-in="#" data-out="#" class="%2$s" id="%1$s">%3$s</ul>',
									'walker'          => new Buscom_Bootstrap_Navwalker(),
								) );
							?>
		                </div><!-- /.navbar-collapse -->
		            </div>
		        </nav>
		        <!-- End Navigation -->
		    </header>
	    <?php
		} elseif ( $header_menu == 'style_two' ) {

			$btn_txt   = $buscom_opt['menu_btn_label'];
			$btn_url   = $buscom_opt['menu_btn_url'];
	    	$logo_l = isset( $buscom_opt['logo_light'] ['url']) ? $buscom_opt['logo_light'] ['url'] : '';
	    	if( $view_layout == 'style_one' ){
	    		$logo_d = isset( $buscom_opt['logo_dark'] ['url']) ? $buscom_opt['logo_dark'] ['url'] : ''; 
	    	}else{
	    		$logo_d = isset( $buscom_opt['logo_light'] ['url']) ? $buscom_opt['logo_light'] ['url'] : '';
	    	}
			?>
			<header id="home">
		        <!-- Start Navigation -->
		        <nav class="navbar active-border navbar-default attr-border-none navbar-fixed navbar-transparent white bootsnav">
		            <div class="container-full">
					<?php if(!empty($btn_txt)) : ?>
		                <!-- Start Atribute Navigation -->
		                <div class="attr-nav">
		                    <ul>
		                        <li class="quote-btn">
		                            <a href="<?php echo esc_url($btn_url); ?>"><?php echo esc_html( $btn_txt ); ?></a>
		                        </li>
		                    </ul>
		                </div>        
		                <!-- End Atribute Navigation -->
					<?php endif; ?>
		                <!-- Start Header Navigation -->
		                <div class="navbar-header">
		                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
		                        <i class="fa fa-bars"></i>
		                    </button>
		                    <a class="navbar-brand" href="<?php echo esc_url( home_url()); ?>">
		                        <img src="<?php echo esc_url($logo_l); ?>" class="logo logo-display" alt="<?php esc_attr_e('Logo', 'buscom' ); ?>">
		                        <img src="<?php echo esc_url($logo_d); ?>" class="logo logo-scrolled" alt="<?php esc_attr_e('Logo', 'buscom' ); ?>">
		                    </a>
		                </div>
		                <!-- End Header Navigation -->
		                <!-- Collect the nav links, forms, and other content for toggling -->
		                <div class="collapse navbar-collapse" id="navbar-menu">
		                    <?php
								wp_nav_menu( array(
									'theme_location'  => 'primary',
									'container'       => 'ul',
									'menu_class'      => 'nav navbar-nav navbar-right',
									'fallback_cb'     => 'Buscom_Bootstrap_Navwalker::fallback',
									'items_wrap'      => '<ul data-in="#" data-out="#" class="%2$s" id="%1$s">%3$s</ul>',
									'walker'          => new Buscom_Bootstrap_Navwalker(),
								) );
							?>
		                </div><!-- /.navbar-collapse -->
		            </div>
		        </nav>
		        <!-- End Navigation -->
		    </header>
		<?php
		} elseif ( $header_menu == 'style_three' ) {
			if( $view_layout == 'style_one' ){
	    		$logo = isset( $buscom_opt['logo_dark'] ['url']) ? $buscom_opt['logo_dark'] ['url'] : ''; 
	    	}else{
	    		$logo = isset( $buscom_opt['logo_light'] ['url']) ? $buscom_opt['logo_light'] ['url'] : '';
	    	}
		    ?>
			<header id="home">
		        <!-- Start Navigation -->
		        <nav class="navbar navbar-default attr-border active-border navbar-sticky bootsnav">
		            <!-- Start Top Search -->
		            <div class="top-search">
		            	<div class="container">
                    		<div class="input-group">
		                        <?php buscom_serch_form(); ?>
		                    </div>
		                </div>
		            </div>
		            <!-- End Top Search -->
		            <div class="container">
		                <!-- Start Atribute Navigation -->
		                <div class="attr-nav">
		                    <ul>
		                        <li class="search"><a href="#"><i class="fas fa-search"></i></a></li>
		                        <?php
		                        if ( class_exists( 'WooCommerce' ) ) { ?>
		                        <li class="login"><a href="<?php echo get_permalink( wc_get_page_id( 'myaccount' ) ); ?>"><i class="fas fa-user"></i></a></li>
		                        
		                    	<?php } ?>
		                    </ul>
		                </div>        
		                <!-- End Atribute Navigation -->
		                <!-- Start Header Navigation -->
		                <div class="navbar-header">
		                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
		                        <i class="fa fa-bars"></i>
		                    </button>
		                    <a class="navbar-brand" href="<?php echo esc_url( home_url()); ?>">
		                        <img src="<?php echo esc_url($logo); ?>" class="logo" alt="<?php esc_attr_e('Logo', 'buscom' ); ?>">
		                    </a>
		                </div>
		                <!-- End Header Navigation -->
		                <!-- Collect the nav links, forms, and other content for toggling -->
		                <div class="collapse navbar-collapse" id="navbar-menu">
		                    <?php
								wp_nav_menu( array(
									'theme_location'  => 'primary',
									'container'       => 'ul',
									'menu_class'      => 'nav navbar-nav navbar-right',
									'fallback_cb'     => 'Buscom_Bootstrap_Navwalker::fallback',
									'items_wrap'      => '<ul data-in="#" data-out="#" class="%2$s" id="%1$s">%3$s</ul>',
									'walker'          => new Buscom_Bootstrap_Navwalker(),
								) );
							?>
		                </div><!-- /.navbar-collapse -->
		            </div>
		        </nav>
		        <!-- End Navigation -->
		    </header>
		<?php
		} elseif ( $header_menu == 'style_four' ) { 
			$logo_l = isset( $buscom_opt['logo_light'] ['url']) ? $buscom_opt['logo_light'] ['url'] : '';

			if( $view_layout == 'style_one' ){
	    		$logo_d = isset( $buscom_opt['logo_dark'] ['url']) ? $buscom_opt['logo_dark'] ['url'] : ''; 
	    	}else{
	    		$logo_d = isset( $buscom_opt['logo_light'] ['url']) ? $buscom_opt['logo_light'] ['url'] : '';
	    	}
	    	$phone  = $buscom_opt['phone'];

	    	$replace        = array(' ','-',' - ');
	    	$with           = array('','','');

	    	$mobileurl      = str_replace( $replace, $with, $phone );
	    	?>
	    	<header id="home">
		        <!-- Start Navigation -->
		        <nav class="navbar navbar-default navbar-fixed navbar-transparent white bootsnav">
		            <!-- Start Top Search -->
		            <div class="top-search">
		                <div class="container-full">
		                    <div class="input-group">
		                        <?php buscom_serch_form(); ?>
		                    </div>
		                </div>
		            </div>
		            <!-- End Top Search -->
		            <div class="container-full">
		            	<?php if (!empty( $phone )) :?>
			                <!-- Start Atribute Navigation -->
			                <div class="attr-nav">
			                    <ul class="contact">
			                        <li class="content">
			                            <div class="icon">
			                                <i class="fas fa-headset"></i>
			                            </div>
			                            <div class="info">
			                                <h6><?php echo esc_html__( 'Need help? Talk to an expert', 'buscom' );?></h6>
			                                <a href="<?php echo esc_attr('tel:'.$mobileurl) ?>"><?php echo esc_html( $phone ) ?></a>
			                            </div>
			                        </li>
			                    </ul>
			                </div>        
			                <!-- End Atribute Navigation -->
			            <?php endif; ?>
		                <!-- Start Header Navigation -->
		                <div class="navbar-header">
		                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
		                        <i class="fa fa-bars"></i>
		                    </button>
		                    <a class="navbar-brand" href="<?php echo esc_url( home_url()); ?>">
		                        <img src="<?php echo esc_url($logo_l); ?>" class="logo logo-display" alt="<?php esc_attr_e('Logo', 'buscom' ); ?>">
		                        <img src="<?php echo esc_url($logo_d); ?>" class="logo logo-scrolled" alt="<?php esc_attr_e('Logo', 'buscom' ); ?>">
		                    </a>
		                </div>
		                <!-- End Header Navigation -->

		                <!-- Collect the nav links, forms, and other content for toggling -->
		                <div class="collapse navbar-collapse" id="navbar-menu">
		                    <?php
		                        wp_nav_menu( array(
		                            'theme_location'  => 'primary',
		                            'container'       => 'ul',
		                            'menu_class'      => 'nav navbar-nav navbar-center',
		                            'fallback_cb'     => 'Buscom_Bootstrap_Navwalker::fallback',
		                            'items_wrap'      => '<ul data-in="#" data-out="#" class="%2$s" id="%1$s">%3$s</ul>',
		                            'walker'          => new Buscom_Bootstrap_Navwalker(),
		                        ) );
		                    ?>
		                </div><!-- /.navbar-collapse -->
		            </div>
		        </nav>
		        <!-- End Navigation -->
		    </header>
		<?php
		} elseif ( $header_menu == 'style_five' ) { ?>

			<header id="home">
		        <!-- Start Navigation -->
		        <nav class="navbar navbar-default attr-border active-border shadow-less logo-less small-pad navbar-sticky bootsnav">
		            <!-- Start Top Search -->
		            <div class="top-search">
		            	<div class="container">
                    		<div class="input-group">
		                        <?php buscom_serch_form(); ?>
		                    </div>
		                </div>
		            </div>
		            <!-- End Top Search -->

		            <div class="container">

		                <!-- Start Atribute Navigation -->
		                <div class="attr-nav">
		                    <ul>
		                        <li class="search"><a href="#"><i class="fas fa-search"></i></a></li>
		                        <?php
		                        if ( class_exists( 'WooCommerce' ) ) { ?>
		                        <li class="login"><a href="<?php echo get_permalink( wc_get_page_id( 'myaccount' ) ); ?>"><i class="fas fa-user"></i></a></li>
		                        
		                    	<?php } ?>
		                    </ul>

		                </div>        
		                <!-- End Atribute Navigation -->
		                 <!-- Start Header Navigation -->
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                                <i class="fa fa-bars"></i>
                            </button>
							<a class="navbar-brand" href="<?php echo esc_url( home_url()); ?>">
								<img src="<?php echo esc_url($logo); ?>" class="logo" alt="<?php esc_attr_e('Logo', 'buscom' ); ?>">
							</a>
                        </div>
                        <!-- End Header Navigation -->
		                <!-- Collect the nav links, forms, and other content for toggling -->
		                <div class="collapse navbar-collapse" id="navbar-menu">
		                    <?php
								wp_nav_menu( array(
									'theme_location'  => 'primary',
									'container'       => 'ul',
									'menu_class'      => 'nav navbar-nav navbar-left',
									'fallback_cb'     => 'Buscom_Bootstrap_Navwalker::fallback',
									'items_wrap'      => '<ul data-in="#" data-out="#" class="%2$s" id="%1$s">%3$s</ul>',
									'walker'          => new Buscom_Bootstrap_Navwalker(),
								) );
							?>
		                </div><!-- /.navbar-collapse -->
		            </div>
		        </nav>
		        <!-- End Navigation -->
		    </header>
		<?php
		} elseif ( $header_menu == 'style_six' ) { 
			$btn_txt   = $buscom_opt['menu_btn_label'];
			$btn_url   = $buscom_opt['menu_btn_url'];
	    	$logo_l = isset( $buscom_opt['logo_light'] ['url']) ? $buscom_opt['logo_light'] ['url'] : '';
	    	if( $view_layout == 'style_one' ){
	    		$logo_d = isset( $buscom_opt['logo_dark'] ['url']) ? $buscom_opt['logo_dark'] ['url'] : ''; 
	    	}else{
	    		$logo_d = isset( $buscom_opt['logo_light'] ['url']) ? $buscom_opt['logo_light'] ['url'] : '';
	    	}
			?>
			<header id="home">
		        <!-- Start Navigation -->
		        <nav class="navbar navbar-default nav-modern navbar-fixed navbar-transparent white bootsnav">
		            <div class="container-full">
					<?php if(!empty($btn_txt)) : ?>
		                <!-- Start Atribute Navigation -->
		                <div class="attr-nav">
		                    <ul>
		                        <li class="quote-btn">
		                            <a href="<?php echo esc_url($btn_url); ?>"><?php echo esc_html( $btn_txt ); ?></a>
		                        </li>
		                    </ul>
		                </div>        
		                <!-- End Atribute Navigation -->
					<?php endif; ?>
		                <!-- Start Header Navigation -->
		                <div class="navbar-header">
		                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
		                        <i class="fa fa-bars"></i>
		                    </button>
		                    <a class="navbar-brand" href="<?php echo esc_url( home_url()); ?>">
		                        <img src="<?php echo esc_url($logo_l); ?>" class="logo logo-display" alt="<?php esc_attr_e('Logo', 'buscom' ); ?>">
		                        <img src="<?php echo esc_url($logo_d); ?>" class="logo logo-scrolled" alt="<?php esc_attr_e('Logo', 'buscom' ); ?>">
		                    </a>
		                </div>
		                <!-- End Header Navigation -->
		                <!-- Collect the nav links, forms, and other content for toggling -->
		                <div class="collapse navbar-collapse" id="navbar-menu">
		                    <?php
								wp_nav_menu( array(
									'theme_location'  => 'primary',
									'container'       => 'ul',
									'menu_class'      => 'nav navbar-nav navbar-center',
									'fallback_cb'     => 'Buscom_Bootstrap_Navwalker::fallback',
									'items_wrap'      => '<ul data-in="#" data-out="#" class="%2$s" id="%1$s">%3$s</ul>',
									'walker'          => new Buscom_Bootstrap_Navwalker(),
								) );
							?>
		                </div><!-- /.navbar-collapse -->
		            </div>
		        </nav>
		        <!-- End Navigation -->
		    </header>

		<?php
		}else {
			if( class_exists('ReduxFramework') && class_exists( 'WooCommerce' ) && !is_shop() && !is_product() && !is_product_category() && !is_product_tag()){
				$buscom_opt 	= get_option('buscom_redux_opt');
				if(is_blog ()){
					if( $buscom_opt['blog_layout_mode'] == '2' ){
			    		$def_logo = isset( $buscom_opt['logo_dark'] ['url']) ? $buscom_opt['logo_dark'] ['url'] : ''; 
			    	}else{
			    		$def_logo = isset( $buscom_opt['logo_light'] ['url']) ? $buscom_opt['logo_light'] ['url'] : '';
			    	}
				}else{
					if( $view_layout == 'style_one' ){
			    		$def_logo = isset( $buscom_opt['logo_dark'] ['url']) ? $buscom_opt['logo_dark'] ['url'] : ''; 
			    	}else{
			    		$def_logo = isset( $buscom_opt['logo_light'] ['url']) ? $buscom_opt['logo_light'] ['url'] : '';
			    	}
				}
			}elseif( class_exists( 'WooCommerce' ) && class_exists('ReduxFramework')){
				if(is_shop() || is_product() || is_product_category() || is_product_tag()){
					$buscom_opt 	= get_option('buscom_redux_opt');
					if( $buscom_opt['woo_layout_mode'] == '2' ){
			    		$def_logo = isset( $buscom_opt['logo_dark'] ['url']) ? $buscom_opt['logo_dark'] ['url'] : ''; 
			    	}else{
			    		$def_logo = isset( $buscom_opt['logo_light'] ['url']) ? $buscom_opt['logo_light'] ['url'] : '';
			    	}
			    }
			}else{
				$def_logo = get_template_directory_uri().'/assets/img/logo.png';
			}
			?>
			<header id="home">
		        <!-- Start Navigation -->
		        <nav class="navbar navbar-default attr-border navbar-sticky bootsnav">
		            <!-- Start Top Search -->
		            <div class="top-search">
		            	<div class="container">
                    		<div class="input-group">
		                        <?php buscom_serch_form(); ?>
		                    </div>
		                </div>
		            </div>
		            <!-- End Top Search -->
		            <div class="container">
		                <!-- Start Atribute Navigation -->
		                <div class="attr-nav">
		                    <ul>
		                    	<?php 
		                    	if ( class_exists( 'WooCommerce' ) ) { ?>
		                        <li class="login"><a href="<?php echo get_permalink( wc_get_page_id( 'myaccount' ) ); ?>"><i class="fas fa-user"></i></a></li>
		                        
		                    	<?php } ?>

		                    </ul>
		                </div>        
		                <!-- End Atribute Navigation -->
		                <!-- Start Header Navigation -->
		                <div class="navbar-header">
		                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
		                        <i class="fa fa-bars"></i>
		                    </button>
		                    <a class="navbar-brand" href="<?php echo esc_url( home_url()); ?>">
		                        <img src="<?php echo esc_url( $def_logo ); ?>" class="logo" alt="<?php esc_attr_e('Logo', 'buscom' ); ?>">
		                    </a>
		                </div>
		                <!-- End Header Navigation -->
		                <!-- Collect the nav links, forms, and other content for toggling -->
		                <div class="collapse navbar-collapse" id="navbar-menu">
		                    <?php
								wp_nav_menu( array(
									'theme_location'  => 'primary',
									'container'       => 'ul',
									'menu_class'      => 'nav navbar-nav navbar-right',
									'fallback_cb'     => 'Buscom_Bootstrap_Navwalker::fallback',
									'items_wrap'      => '<ul data-in="#" data-out="#" class="%2$s" id="%1$s">%3$s</ul>',
									'walker'          => new Buscom_Bootstrap_Navwalker(),
								) );
							?>
		                </div><!-- /.navbar-collapse -->
		            </div>
		        </nav>
		        <!-- End Navigation -->
		    </header>
		<?php
		}
		
	}
}
add_action( 'buscom_header', 'buscom_topbar', 20 );
add_action( 'buscom_header', 'buscom_main_menu', 21 );