<?php
/**
 * Helper files for this theme.
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package BUSCOM
 */

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function buscom_widgets_init() {


	/* Register the primary sidebar. */
	register_sidebar( array(
		'name'          => esc_html__( 'Blog sidebar', 'buscom' ),
		'id'            => 'primary-sidebar',
		'description'   => esc_html__( 'Widgets will be shown in blog area.', 'buscom' ),
		'before_widget' => '<div id="%1$s" class="sidebar-item %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<div class="title"><h4>',
		'after_title'   => '</h4></div>',
	) );

	if( class_exists( 'ReduxFramework' ) ){

		/* Register the service sidebar. */
		register_sidebar( array(
			'name'          => esc_html__( 'Service  sidebar', 'buscom' ),
			'id'            => 'service-single-sidebar',
			'description'   => esc_html__( 'Place widgets here for service area page.', 'buscom' ),
			'before_widget' => '<div id="%1$s" class="sidebar-item %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<div class="title"><h4>',
			'after_title'   => '</h4></div>',
		) );
	
		/* Register the footer sidebar. */
		register_sidebar( array(
			'name'          => esc_html__( 'Footer One', 'buscom' ),
			'id'            => 'footer-widgets-1',
			'description'   => esc_html__( 'Widgets will be shown in footer area.', 'buscom' ),
			'before_widget' => '<div id="%1$s" class="equal-height col-md-4 col-sm-6 item"><div class="f-item %2$s">',
			'after_widget'  => '</div></div>',
			'before_title'  => '<h4 class="widget-title">',
			'after_title'   => '</h4>',
		) );

		register_sidebar( array(
			'name'          => esc_html__( 'Footer Two', 'buscom' ),
			'id'            => 'footer-widgets-2',
			'description'   => esc_html__( 'Widgets will be shown in footer area.', 'buscom' ),
			'before_widget' => '<div id="%1$s" class="equal-height col-md-2 col-sm-6 item"><div class="f-item %2$s">',
			'after_widget'  => '</div></div>',
			'before_title'  => '<h4 class="widget-title">',
			'after_title'   => '</h4>',
		) );

		register_sidebar( array(
			'name'          => esc_html__( 'Footer Three', 'buscom' ),
			'id'            => 'footer-widgets-3',
			'description'   => esc_html__( 'Widgets will be shown in footer area.', 'buscom' ),
			'before_widget' => '<div id="%1$s" class="equal-height col-md-2 col-sm-6 item"><div class="f-item %2$s">',
			'after_widget'  => '</div></div>',
			'before_title'  => '<h4 class="widget-title">',
			'after_title'   => '</h4>',
		) );

		register_sidebar( array(
			'name'          => esc_html__( 'Footer Four', 'buscom' ),
			'id'            => 'footer-widgets-4',
			'description'   => esc_html__( 'Widgets will be shown in footer area.', 'buscom' ),
			'before_widget' => '<div id="%1$s" class="equal-height col-md-4 col-sm-6 item"><div class="f-item %2$s">',
			'after_widget'  => '</div></div>',
			'before_title'  => '<h4 class="widget-title">',
			'after_title'   => '</h4>',
		) );

		if( class_exists('woocommerce') ) {
	        register_sidebar(
	            array(
	                'name'          => esc_html__( 'WooCommerce Sidebar', 'buscom' ),
	                'id'            => 'buscom-woo-sidebar',
	                'description'   => esc_html__( 'Add widgets here to appear in your woocommerce page sidebar.', 'buscom' ),
	                'before_widget' => '<div class="widget %2$s">',
	                'after_widget'  => '</div>',
	                'before_title'  => '<div class="widget_title"><h4>',
	                'after_title'   => '</h4></div>',
	            )
	        );
	    }
	}
}
add_action( 'widgets_init', 'buscom_widgets_init' );

/**
 * Wrapper function to deal with backwards compatibility.
 */
if ( ! function_exists( 'buscom_body_open' ) ) {
	function buscom_body_open() {
		if ( function_exists( 'wp_body_open' ) ) {
			wp_body_open();
		} else {
			do_action( 'wp_body_open' );
		}
	}
}

/** Category count on rightside **/

function buscom_category_count_on_rightside($links) {
  $links = str_replace('</a> (', '</a> <span>', $links);
  $links = str_replace(')', '</span>', $links);
  return $links;
}
add_filter('wp_list_categories', 'buscom_category_count_on_rightside');

/** Excerpt Section Blog Post **/
if ( ! function_exists( 'buscom_excerpt' ) ) :
	function buscom_excerpt($limit) {
	  $excerpt = explode(' ', get_the_excerpt(), $limit);
	  if (count($excerpt)>=$limit) {
	    array_pop($excerpt);
	    $excerpt = implode(" ",$excerpt);
	  } else {
	    $excerpt = implode(" ",$excerpt);
	  }
	  $excerpt = preg_replace('`[[^]]*]`','',$excerpt);
	  return $excerpt;
	}
endif;

/** Posts Pagination **/
if ( ! function_exists( 'buscom_pagination' ) ) :
	function buscom_pagination($pages='') {
     global $wp_query;
	    $links = paginate_links( array(
	        'current' => max( 1, get_query_var( 'paged' ) ),
	        'total'   => $wp_query->max_num_pages,
	        'type'    => 'list',
	        'prev_text' => wp_specialchars_decode(esc_html__( '<i class="fas fa-angle-double-left"></i>', 'buscom' ),ENT_QUOTES),
	    	'next_text' => wp_specialchars_decode(esc_html__( '<i class="fas fa-angle-double-right"></i>', 'buscom' ),ENT_QUOTES),
	    ) );

	    $links = str_replace( 'page-numbers', 'pagination', $links );

	    echo wp_specialchars_decode( $links );
	}
endif;

/** Posts Pagination for woocommerce**/
if ( ! function_exists( 'buscom_woo_pagination' ) ) :
	function buscom_woo_pagination($pages='') {
     global $wp_query;
	    $links = paginate_links( array(
	        'current' => max( 1, get_query_var( 'paged' ) ),
	        'total'   => $wp_query->max_num_pages,
	        'type'    => 'list',
	        'prev_text' => wp_specialchars_decode(esc_html__( '<i class="fas fa-angle-double-left"></i>', 'buscom' ),ENT_QUOTES),
	    	'next_text' => wp_specialchars_decode(esc_html__( '<i class="fas fa-angle-double-right"></i>', 'buscom' ),ENT_QUOTES),
	    ) );

	    echo wp_specialchars_decode( $links );
	}
endif;

// ** Posts comments **/
if( !function_exists('buscom_comments') ) {

	function buscom_comments( $comment, $args, $depth ) {
	    $GLOBALS['comment'] = $comment; ?>
	    <div class="commen-item <?php if($depth >= 2){ echo esc_html( 'reply', 'buscom' );}?>">
	        <li <?php comment_class(); ?> id="li-comment-<?php comment_ID() ?>">
		        <article id="comment-<?php comment_ID(); ?>" class="comment-wrap clearfix">
		            <?php if ( $avarta = get_avatar( $comment, $size='80' ) ) :
		                printf( '<div class="avatar">%1$s</div>', $avarta );
		            endif; ?>
		            <div class='content'>
		            	<div class="title">
			                <?php 
			                    if ( $comment->user_id != '0' ) {
			                        printf( '<h5>%1$s</h5>', get_user_meta( $comment->user_id, 'nickname', true ) );
			                    } else {
			                        printf( '<h5>%1$s</h5>', get_comment_author_link() );
			                    }
			                        edit_comment_link( esc_html__( 'Edit', 'buscom' ), '', '' ); 
			                ?>
			                <span><?php echo get_comment_date(); ?></span>
						</div>
						<?php comment_text() ?>
		                <div class='comments-info'>
		                    
		                    <?php if ( $comment->comment_approved == '0' ) : ?>
		                        <span class="unapproved"><?php esc_html_e( 'Your comment is awaiting moderation.', 'buscom' ); ?></span>
		                    <?php endif; ?>
		                    <?php 
		                    comment_reply_link(array_merge( $args, 
		                        array(
		                            'reply_text' => sprintf( '<i class="fa fa-reply"></i> %s', esc_html__( 'Reply', 'buscom' ) ), 
		                            'depth' => $depth, 
		                            'max_depth' => $args['max_depth']
		                        )
		                    )); ?>
		                </div>
		            </div>
		        </article>
		    </li>
	    </div>
	<?php 
	} 
}

// Social Links
if( !function_exists('buscom_social_links') ) {
	function buscom_social_links() {
	    $buscom_opt = get_option('buscom_redux_opt');
	    $facebook       = $buscom_opt['facebook_url'];
	    $twitter        = $buscom_opt['twitter_url'];
	    $pinterest      = $buscom_opt['pinterest_url'];
	    $dribbble       = $buscom_opt['dribbble_url'];

	    ?>
	    <ul class="social">
			<?php if (!empty( $facebook )) :?>
				<li><a href="<?php echo esc_url($facebook); ?>"><i class="fab fa-facebook-f"></i></a></li>
			<?php endif; ?>
			<?php if (!empty( $twitter )) :?>
				<li><a href="<?php echo esc_url($twitter); ?>"><i class="fab fa-twitter"></i></a></li>
			<?php endif; ?>
			<?php if (!empty( $pinterest )) :?>
				<li><a href="<?php echo esc_url($pinterest); ?>"><i class="fab fa-pinterest-p"></i></a></li>
			<?php endif; ?>
			<?php if (!empty( $dribbble )) :?>
				<li><a href="<?php echo esc_url($dribbble); ?>"><i class="fab fa-dribbble"></i></a></li>
			<?php endif; ?>
		</ul>
	<?php
	}
}

// Buscom 404 Serch Form
if( !function_exists('buscom_serch_form_v2') ) {
	function buscom_serch_form_v2() {
	    ?>
		<form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
		    <input name="s"  type="search" class="form-control" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="<?php echo esc_attr__('Search', 'buscom'); ?>">
		    <button type="submit">
		    <i class="fas fa-search"></i>
		    </button>
		</form>
	<?php
	}
}

// Buscom info meta
if( !function_exists('buscom_informations') ) {
	function buscom_informations() {
		$buscom_opt = get_option('buscom_redux_opt');
	    $email          = $buscom_opt['email'];
	    $phone          = $buscom_opt['phone'];
	    $office_hours   = $buscom_opt['o_hours'];

	    $email          = is_email( $email );

	    $replace        = array(' ','-',' - ');
	    $with           = array('','','');

	    $emailurl       = str_replace( $replace, $with, $email );
	    $mobileurl      = str_replace( $replace, $with, $phone );

	    ?>
	    <ul>
			<?php
			if (!empty( $email )) :?>
				<li>
					<div class="icon">
						<i class="flaticon-email"></i>
					</div>
					<div class="info">
						<span><?php echo esc_html__( 'Email', 'buscom' );?></span><a href="<?php echo esc_attr( 'mailto:'.$emailurl ) ?>"><?php echo esc_html( $email ) ?></a>
					</div>
				</li>
			<?php endif; ?>
			<?php
			if (!empty( $phone )) :?>
				<li>
					<div class="icon">
						<i class="flaticon-call-center"></i>
					</div>
					<div class="info">
						<span><?php echo esc_html__( 'Phone', 'buscom' );?></span><a href="<?php echo esc_attr('tel:'.$mobileurl) ?>"><?php echo esc_html( $phone ) ?></a>
					</div>
				</li>
			<?php endif; ?>
			<?php
			if (!empty( $office_hours )) :?>
				<li>
					<div class="icon">
						<i class="flaticon-countdown"></i>
					</div>
					<div class="info">
						<span><?php echo esc_html__( 'Office Hours', 'buscom' );?></span> <?php echo esc_html( $office_hours );?>
					</div>
				</li>
			<?php endif; ?>
		</ul>
	<?php
	}
}

// Buscom Top Serch Form
if( !function_exists('buscom_serch_form') ) {
	function buscom_serch_form() {
	    ?>
	    <span class="input-group-addon"><i class="fa fa-search"></i></span>
		<form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
		    <input name="s"  type="search" class="form-control" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="<?php echo esc_attr__('Search', 'buscom'); ?>">
		    <span class="input-group-addon close-search"><i class="fa fa-times"></i></span>
		</form>
	<?php
	}
}

//Mimes allowed file uploads

function buscom_allow_mime_types( $mimes ) {

    $mimes['svg'] = 'image/svg+xml';
    $mimes['svgz'] = 'image/svgz+xml';
    $mimes['json'] = 'application/json'; 
    $mimes['exe'] = 'program/exe';
    $mimes['dwg'] = 'image/vnd.dwg';
    return $mimes;
}

add_filter('upload_mimes', 'buscom_allow_mime_types');

// Buscom Body class for dark version page layout
if( class_exists('ReduxFramework') ) {
	function custom_body_classes( $classes ){
		
		global $post;
	    $view_layout = get_post_meta( get_the_id(), '_page-style', true);
	    function is_blog () {
		    return ( is_archive() || is_author() || is_category() || is_home() || is_single() || is_tag()) && 'post' == get_post_type();
		}
		$buscom_opt = get_option('buscom_redux_opt');

	    if( is_page_template('templates/simple-page.php') ){
	    	if( $view_layout == 'style_one' ){
	    		$classes[] 		= 'no-layout'; 
	    	}else{
	    		$classes[] 		= 'dark-layout'; 
	    	}

	    }elseif( is_page_template('templates/vc-page.php') ){
	    	if( $view_layout == 'style_one' ){
	    		$classes[] 		= 'no-layout'; 
	    	}else{
	    		$classes[] 		= 'dark-layout'; 
	    	}

	    }elseif( is_page_template('templates/it-solution-template.php') ){
	    	if( $view_layout == 'style_one' ){
	    		$classes[] 		= 'blue'; 
	    	}else{
	    		$classes[] 		= 'blue'; 
	    	}

	    }elseif( is_page_template('templates/vc-page-with-breadcumb.php') ){
	    	if( $view_layout == 'style_one' ){
	    		$classes[] 		= 'no-layout'; 
	    	}else{
	    		$classes[] 		= 'dark-layout'; 
	    	}
	    }elseif(get_post_type() === 'buscom-service' ){
	    	if( $view_layout == 'style_one' ){
	    		$classes[] 		= 'no-layout'; 
	    	}else{
	    		$classes[] 		= 'dark-layout'; 
	    	}
	    }elseif(get_post_type() === 'buscom-gallery' ){
	    	if( $view_layout == 'style_one' ){
	    		$classes[] 		= 'no-layout'; 
	    	}else{
	    		$classes[] 		= 'dark-layout'; 
	    	}
	    }elseif(get_post_type() === 'buscom-team' ){
	    	if( $view_layout == 'style_one' ){
	    		$classes[] 		= 'no-layout'; 
	    	}else{
	    		$classes[] 		= 'dark-layout'; 
	    	}
	    }elseif(get_post_type() === 'page' ){
	    	if( $view_layout == 'style_one' ){
	    		$classes[] 		= 'no-layout'; 
	    	}else{
	    		$classes[] 		= 'dark-layout'; 
	    	}
	    }elseif(is_page( 'cart' ) ){
	    	if( $view_layout == 'style_one' ){
	    		$classes[] 		= 'no-layout'; 
	    	}else{
	    		$classes[] 		= 'dark-layout'; 
	    	}
	    }elseif(is_page( 'checkout' ) ){
	    	if( $view_layout == 'style_one' ){
	    		$classes[] 		= 'no-layout'; 
	    	}else{
	    		$classes[] 		= 'dark-layout'; 
	    	}
	    }elseif(is_page( 'wishlist' ) ){
	    	if( $view_layout = 'style_one' ){
	    		$classes[] 		= 'no-layout'; 
	    	}else{
	    		$classes[] 		= 'dark-layout'; 
	    	}
	    }elseif(is_page( 'my-account' ) ){
	    	if( $view_layout == 'style_one' ){
	    		$classes[] 		= 'no-layout'; 
	    	}else{
	    		$classes[] 		= 'dark-layout'; 
	    	}
	    }elseif(is_shop() || is_product() || is_product_category() || is_product_tag() ){
	    	if( $buscom_opt['woo_layout_mode'] == '1' ){
	    		$classes[] 		= 'dark-layout'; 
	    	}else{
	    		$classes[] 		= 'no-layout'; 
	    	}
	    }elseif( get_post_type() == 'post' ){
	    	if( $buscom_opt['blog_layout_mode'] == '1' ){
	    		$classes[] 		= 'dark-layout'; 
	    	}else{
	    		$classes[] 		= 'no-layout'; 
	    	}
	    }else{
	    	$classes[] 			= 'def-layout';
	    }
	    return $classes;	
	}

add_filter( 'body_class', 'custom_body_classes' );
}

// buscom woocommerce breadcrumb
function buscom_woo_breadcrumb( $args ) {
    return array(
        'delimiter'   => '',
        'wrap_before' => '',
        'wrap_after'  => '',
        'before'      => '<li>',
        'after'       => '</li>',
        // 'home'        => _x( 'Home', 'breadcrumb', 'buscom' ),
    );
}

add_filter( 'woocommerce_breadcrumb_defaults', 'buscom_woo_breadcrumb' );

// image alt tag
function buscom_image_alt( $url = '' ){
    if( $url != '' ){
        // attachment id by url
        $attachmentid = attachment_url_to_postid( esc_url( $url ) );
       // attachment alt tag
        $image_alt = get_post_meta( esc_html( $attachmentid ) , '_wp_attachment_image_alt', true );
        if( $image_alt ){
            return $image_alt ;
        }else{
            $filename = pathinfo( esc_url( $url ) );
            $alt = str_replace( '-', ' ', $filename['filename'] );
            return $alt;
        }
    }else{
       return;
    }
}

// image default alt
if( !function_exists( 'buscom_img_default_alt' ) ){
	function buscom_img_default_alt( $url = '' ){

		if( $url != '' ){
			// attachment id by URL 
			$attachmentid = attachment_url_to_postid( esc_url( $url ) );
		   // attachment alt tag 
			$image_alt = get_post_meta( esc_html( $attachmentid ) , '_wp_attachment_image_alt', true );
			
			if( $image_alt ){
				return $image_alt ;
			}else{
				$filename = pathinfo( esc_url( $url ) );
		
				$alt = str_replace( '-', ' ', $filename['filename'] );
				
				return $alt;
			}
		}else{
		   return; 
		}

	}
}

function buscom_core_essential_scripts( ) {
    wp_localize_script(
    'buscom-ajax',
    'buscomajax',
        array(
            'action_url' => admin_url( 'admin-ajax.php' ),
            'nonce'	     => wp_create_nonce( 'buscom-nonce' ),
        )
    );
}

add_action('wp_enqueue_scripts','buscom_core_essential_scripts');

// popup subscribe form
if( !function_exists( 'buscom_popup_subscribe_form' ) ){
	function buscom_popup_subscribe_form(){ 
		if( class_exists('ReduxFramework') ) {
			$buscom_opt = get_option('buscom_redux_opt');
			if ($buscom_opt['popup_subscribed_form_position'] == 1){
				$allowhtml = array(
				    'p'         => array(
				        'class'     => array()
				    ),
				    'span'      => array(
				        'class'     => array(),
				    ),
				    'a'         => array(
				        'href'      => array(),
				        'title'     => array(),
				        'class'     => array(),
				    ),
				    'br'        => array(),
				    'em'        => array(),
				    'strong'    => array(),
				    'b'         => array(),
				); ?>
				<!-- Subscribe Form -->
				<div id="myModal" class="modal fade">
				    <div class="modal-dialog">
				        <div class="modal-content">
				            <!-- Modal Banner -->
				            <div class="modal-banner"></div>
				            <!-- end Modal Banner -->
				            <button type="button" class="close" data-dismiss="modal"><i class="fas fa-times"></i></button>
				            <div class="modal-body">
				            	<?php if(!empty($buscom_opt['popup_subscribed_form_subtitle'])) { ?>
				                	<h4><?php echo wp_kses( $buscom_opt['popup_subscribed_form_subtitle'] , $allowhtml) ?></h4>
				            	<?php } ?>
				            	<?php if(!empty($buscom_opt['popup_subscribed_form_title'])) { ?>
				                	<h2><?php echo esc_html($buscom_opt['popup_subscribed_form_title']) ?></h2>
				                <?php } ?>
				                <?php if(!empty($buscom_opt['popup_subscribed_form_desc'])) { ?>
				                	<p><?php echo wp_kses( $buscom_opt['popup_subscribed_form_desc'] , $allowhtml) ?></p>
				            	<?php } ?>
				            	<?php 
				            	if(!empty($buscom_opt['popup_subscribed_form_shortcode'])) { 
				            		echo do_shortcode( $buscom_opt['popup_subscribed_form_shortcode'] );
				            	}
				            	?>     
				            </div>
				        </div>
				    </div>
				</div>
				<!-- End Subscribe Form -->
			<?php
			}
		}
	}
}