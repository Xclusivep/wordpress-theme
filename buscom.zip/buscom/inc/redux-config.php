<?php
    /**
     * ReduxFramework Sample Config File
     * For full documentation, please visit: http://docs.reduxframework.com/
     */

    if ( ! class_exists( 'Redux' ) ) {
        return;
    }


    // This is your option name where all the Redux data is stored.
    $opt_name = "buscom_redux_opt";

    // This line is only for altering the demo. Can be easily removed.
    $opt_name = apply_filters( 'redux_demo/opt_name', $opt_name );

    /*
     *
     * --> Used within different fields. Simply examples. Search for ACTUAL DECLARATION for field examples
     *
     */

    $sampleHTML = '';
    if ( file_exists( dirname( __FILE__ ) . '/info-html.html' ) ) {
        Redux_Functions::initWpFilesystem();

        global $wp_filesystem;

        $sampleHTML = $wp_filesystem->get_contents( dirname( __FILE__ ) . '/info-html.html' );
    }

    // Background Patterns Reader
    $sample_patterns_path = ReduxFramework::$_dir . '../sample/patterns/';
    $sample_patterns_url  = ReduxFramework::$_url . '../sample/patterns/';
    $sample_patterns      = array();
    
    if ( is_dir( $sample_patterns_path ) ) {

        if ( $sample_patterns_dir = opendir( $sample_patterns_path ) ) {
            $sample_patterns = array();

            while ( ( $sample_patterns_file = readdir( $sample_patterns_dir ) ) !== false ) {

                if ( stristr( $sample_patterns_file, '.png' ) !== false || stristr( $sample_patterns_file, '.jpg' ) !== false ) {
                    $name              = explode( '.', $sample_patterns_file );
                    $name              = str_replace( '.' . end( $name ), '', $sample_patterns_file );
                    $sample_patterns[] = array(
                        'alt' => $name,
                        'img' => $sample_patterns_url . $sample_patterns_file
                    );
                }
            }
        }
    }

    /**
     * ---> SET ARGUMENTS
     * All the possible arguments for Redux.
     * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
     * */

    $theme = wp_get_theme(); // For use with some settings. Not necessary.

    $args = array(
        // TYPICAL -> Change these values as you need/desire
        'opt_name'             => $opt_name,
        // This is where your data is stored in the database and also becomes your global variable name.
        'display_name'         => $theme->get( 'Name' ),
        // Name that appears at the top of your panel
        'display_version'      => $theme->get( 'Version' ),
        // Version that appears at the top of your panel
        'menu_type'            => 'menu',
        //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
        'allow_sub_menu'       => true,
        // Show the sections below the admin menu item or not
        'menu_title'           => __( 'Buscom Theme Options', 'buscom' ),
        'page_title'           => __( 'Theme Options', 'buscom' ),
        // You will need to generate a Google API key to use this feature.
        // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
        'google_api_key'       => '',
        // Set it you want google fonts to update weekly. A google_api_key value is required.
        'google_update_weekly' => false,
        // Must be defined to add google fonts to the typography module
        'async_typography'     => false,
        // Use a asynchronous font on the front end or font string
        //'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
        'admin_bar'            => true,
        // Show the panel pages on the admin bar
        'admin_bar_icon'       => 'dashicons-portfolio',
        // Choose an icon for the admin bar menu
        'admin_bar_priority'   => 50,
        // Choose an priority for the admin bar menu
        'global_variable'      => '',
        // Set a different name for your global variable other than the opt_name
        'dev_mode'             => false,
        // Show the time the page took to load, etc
        'update_notice'        => false,
        // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
        'customizer'           => true,
        // Enable basic customizer support
        //'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
        //'disable_save_warn' => true,                    // Disable the save warning when a user changes a field

        // OPTIONAL -> Give you extra features
        'page_priority'        => null,
        // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
        'page_parent'          => 'themes.php',
        // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
        'page_permissions'     => 'manage_options',
        // Permissions needed to access the options panel.
        'menu_icon'            => '',
        // Specify a custom URL to an icon
        'last_tab'             => '',
        // Force your panel to always open to a specific tab (by id)
        'page_icon'            => 'icon-themes',
        // Icon displayed in the admin panel next to your menu_title
        'page_slug'            => '',
        // Page slug used to denote the panel, will be based off page title then menu title then opt_name if not provided
        'save_defaults'        => true,
        // On load save the defaults to DB before user clicks save or not
        'default_show'         => false,
        // If true, shows the default value next to each field that is not the default value.
        'default_mark'         => '',
        // What to print by the field's title if the value shown is default. Suggested: *
        'show_import_export'   => true,
        // Shows the Import/Export panel when not used as a field.

        // CAREFUL -> These options are for advanced use only
        'transient_time'       => 60 * MINUTE_IN_SECONDS,
        'output'               => true,
        // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
        'output_tag'           => true,
        // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
        // 'footer_credit'     => '',                   // Disable the footer credit of Redux. Please leave if you can help it.

        // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
        'database'             => '',
        // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
        'use_cdn'              => true,
        // If you prefer not to use the CDN for Select2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.

        // HINTS
        'hints'                => array(
            'icon'          => 'el el-question-sign',
            'icon_position' => 'right',
            'icon_color'    => 'lightgray',
            'icon_size'     => 'normal',
            'tip_style'     => array(
                'color'   => 'red',
                'shadow'  => true,
                'rounded' => false,
                'style'   => '',
            ),
            'tip_position'  => array(
                'my' => 'top left',
                'at' => 'bottom right',
            ),
            'tip_effect'    => array(
                'show' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'mouseover',
                ),
                'hide' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'click mouseleave',
                ),
            ),
        )

    );

    // Add content after the form.

    $args['footer_text'] = 'Copyright Buscom &copy; '.date('Y').'';
    Redux::setArgs( $opt_name, $args );

    /*
     * ---> END ARGUMENTS
     */

    //General Theme Settings
    Redux::setSection($opt_name, array(
        'title'     => esc_html__('General Options', 'buscom'),
        'id'        => 'general-options',
        'icon'      => 'el-icon-cogs',
        'fields'    => array(
            array(
                'id'        => 'favicon',
                'title'     => esc_html__('Upload  Favicon Logo','buscom'), 
                'type'      => 'media',
                'default'   => array(
                    'url' => get_template_directory_uri().'/assets/img/favicon.png',
                ),
            ), 
            array(
                'id'        => 'breadcumb_position',
                'type'      => 'switch',
                'title'     => esc_html__( 'Breadcumb Hide/Show', 'buscom' ),
                'default'   => 1,
                'on'        => esc_html__('Enable', 'buscom'),
                'off'       => esc_html__('Disable', 'buscom'),
            ),
            array(
                'id'       => 'breadcumb_bg',
                'type'     => 'background',
                'title'    => esc_html__( 'Breadcrumb Background', 'buscom' ),
                'subtitle' => esc_html__( 'Set Title Color note: this effect is not allow for show on dark version', 'buscom' ),
                'required'  => array( 'breadcumb_position', '=', '1' ),
                'output'   => array('.buscom-breadcrumb'),
            ),
            array(
                'id'       => 'buscom_breadcrumb_title_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Breadcrumb Title Color', 'buscom' ),
                'subtitle' => esc_html__( 'Set Title Color', 'buscom' ),
                'output'   => array( 'color' => '.buscom-breadcrumb h1' ),
            ),
            array(
                'id'        => 'popup_subscribed_form_position',
                'type'      => 'switch',
                'title'     => esc_html__( 'Popup Subscribed Form Hide/Show', 'buscom' ),
                'default'   => 1,
                'on'        => esc_html__('Enable', 'buscom'),
                'off'       => esc_html__('Disable', 'buscom'),
            ),
            array(
                'id'       => 'popup_subscribed_form_subtitle',
                'type'     => 'text',
                'title'    => esc_html__( 'Subscribed Form Subtitle', 'buscom' ),
                'default'  => esc_html__( 'GET UP TO <strong>25% OFF</strong>', 'buscom' ),
                'required'  => array( 'popup_subscribed_form_position', '=', '1' ),
            ),
            array(
                'id'       => 'popup_subscribed_form_title',
                'type'     => 'text',
                'title'    => esc_html__( 'Subscribed Form Title', 'buscom' ),
                'default'  => esc_html__( 'Sign up to Buscom', 'buscom' ),
                'required'  => array( 'popup_subscribed_form_position', '=', '1' ),
            ),
            array(
                'id'       => 'popup_subscribed_form_desc',
                'type'     => 'textarea',
                'title'    => esc_html__( 'Subscribed Form Short Description', 'buscom' ),
                'default'  => esc_html__( 'Subscribe to the Maxa market newsletter <br> to receive updates on special offers.', 'buscom' ),
                'required'  => array( 'popup_subscribed_form_position', '=', '1' ),
            ),
            array(
                'id'       => 'popup_subscribed_form_shortcode',
                'type'     => 'text',
                'title'    => esc_html__( 'Form Shortcode', 'buscom' ),
                'default'  => esc_html__( '', 'buscom' ),
                'required'  => array( 'popup_subscribed_form_position', '=', '1' ),
            ),
            array(
                'id'       => 'popup_subscribed_form_bg',
                'type'     => 'background',
                'title'    => esc_html__( 'Form Background', 'buscom' ),
                'output'   => array('.modal-banner'),
                'required'  => array( 'popup_subscribed_form_position', '=', '1' ),
            ),

        )
    ));

    //Theme Header Settings
    Redux::setSection($opt_name, array(
        'icon'      => 'dashicons dashicons-schedule',
        'title'     => esc_html__('Header Informations', 'buscom'),
        'id'        => 'header_settings',
        'fields'    => array( 
            array(
                'title'    => esc_html__('Email','buscom' ),
                'id'       => 'email',
                'type'     => 'text',
                'validate' => 'email',
                'msg'      => 'Invalid Email Address',
                'default'  => 'Info@gmail.com',     
            ),
            array(
                'title'    => esc_html__('Phone','buscom' ),
                'id'       => 'phone',
                'type'     => 'text',
                'default'  => '+123 456 7890',     
            ),
            array(
                'id'       => 'o_hours',
                'type'     => 'text',
                'title'    => esc_html__('Office Hours','buscom' ),
                'default'  => 'Sat - Wed : 8:00 - 4:00',      
            ),
            array(
                'id'       => 'facebook_url',
                'type'     => 'text',
                'title'    => esc_html__('Facebook URL','buscom' ),
                'validate' => 'url',
                'default'  => 'https://www.facebook.com',     
            ),
            array(
                'id'       => 'twitter_url',
                'type'     => 'text',
                'title'    => esc_html__('Twitter URL','buscom' ),
                'validate' => 'url',
                'default'  => 'https://www.twitter.com',     
            ),
            array(
                'id'       => 'pinterest_url',
                'type'     => 'text',
                'title'    => esc_html__('Pinterest URL','buscom' ),
                'validate' => 'url',
                'default'  => 'https://www.pinterest.com',     
            ),
            array(
                'id'       => 'dribbble_url',
                'type'     => 'text',
                'title'    => esc_html__('Dribbble URL','buscom' ),
                'validate' => 'url',
                'default'  => 'https://www.dribble.com',     
            ),
            array(
                'title'     => esc_html__('Header Logo', 'buscom'),
                'subtitle'  => esc_html__( 'Upload here a logo image file for header', 'buscom' ),
                'id'        => 'header_logo',
                'type'      => 'media',
                'url'       => true,
                'default'   => array(
                    'url'   => get_template_directory_uri().'/assets/img/logo.png'
                )
            ),
        ),
    ));

    //Theme Navbar styling
    Redux::setSection($opt_name, array(
        'icon'      => 'dashicons dashicons-menu-alt3',
        'title'     => esc_html__('Header menu styling', 'buscom'),
        'id'        => 'navbar_settings',
        'fields'    => array( 
            array(
                'id'        => 'sidemenu_position',
                'type'      => 'switch',
                'title'     => esc_html__( 'Slide Menu Hide/Show', 'buscom' ),
                'on'        => esc_html__('Enable', 'buscom'),
                'off'       => esc_html__('Disable', 'buscom'),
                'default'   => 1,
                'subtitle'  => esc_html__('If you want to show slide menu in right side of menu bar Enable this, and if you dont want to show then you may disable this.', 'buscom'),
            ),
            array(
                'title'     => esc_html__('Logo Light', 'buscom'),
                'subtitle'  => esc_html__( 'For this transparent menu bar upload here a light logo image file', 'buscom' ),
                'id'        => 'logo_light',
                'type'      => 'media',
                'url'       => true,
                'default'   => array(
                    'url'   => get_template_directory_uri().'/assets/img/logo-light.png'
                )
            ),
            array(
                'title'     => esc_html__('Logo Dark', 'buscom'),
                'subtitle'  => esc_html__( 'For this transparent menu bar upload here a dark logo image file', 'buscom' ),
                'id'        => 'logo_dark',
                'type'      => 'media',
                'url'       => true,
                'default'   => array(
                    'url'   => get_template_directory_uri().'/assets/img/logo.png'
                )
            ),
            array(
                'title'     => esc_html__('Button label', 'buscom'),
                'subtitle'  => esc_html__('Leave the button label field empty to hide the menu action button.', 'buscom'),
                'id'        => 'menu_btn_label',
                'type'      => 'text',
                'default'   => esc_html__('Get Started', 'buscom'),
            ),
            array(
                'title'     => esc_html__('Button URL', 'buscom'),
                'id'        => 'menu_btn_url',
                'type'      => 'text',
                'default'   => '#',
            ),
        ),
    ));

    // -> START Woo Page Option

    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Woocommerce Page', 'buscom' ),
        'id'         => 'buscom_woo__page',
        'icon'  => 'el el-shopping-cart',
        'fields'     => array(
            array(
                'id'       => 'woo_breadcumb_bg',
                'type'     => 'background',
                'title'    => esc_html__( 'Breadcrumb Background', 'buscom' ),
                'output'   => array('.buscom-woo-breadcrumb'),
                'subtitle' => esc_html__( 'This breadcrumb imgae only show on woocomerce related all pages', 'buscom' ),
            ),
            array(
                'id'       => 'buscom_woo_breadcrumb_title_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Breadcrumb Title Color', 'buscom' ),
                'subtitle' => esc_html__( 'Set Title Color note: this effect is not allow for show on dark version', 'buscom' ),
                'output'   => array( 'color' => '.buscom-woo-breadcrumb h1' ),
            ),
            array(
                'id'       => 'buscom_woo_shoppage_sidebar',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Set Shop Page Sidebar.', 'buscom' ),
                'subtitle' => esc_html__( 'Choose shop page sidebar', 'buscom' ),
                //Must provide key => value(array:title|img) pairs for radio options
                'options'  => array(
                    '1' => array(
                        'alt' => esc_attr__('No Sideber','buscom'),
                        'img' => esc_url( get_template_directory_uri(). '/assets/img/no-sideber.jpg')
                    ),
                    '2' => array(
                        'alt' => esc_attr__('Left Sideber','buscom'),
                        'img' => esc_url( get_template_directory_uri() .'/assets/img/left-sideber.jpg')
                    ),
                    '3' => array(
                        'alt' => esc_attr__('Right Sideber','buscom'),
                        'img' => esc_url(  get_template_directory_uri() .'/assets/img/right-sideber.jpg' )
                    ),

                ),
                'default'  => '1'
            ),
            array(
                'id'       => 'buscom_woo_product_col',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Product Column', 'buscom' ),
                'subtitle' => esc_html__( 'Set your woocommerce product column.', 'buscom' ),
                //Must provide key => value(array:title|img) pairs for radio options
                'options'  => array(
                    '2' => array(
                        'alt' => esc_attr__('2 Columns','buscom'),
                        'img' => esc_url( get_template_directory_uri() .'/assets/img/2col.jpg')
                    ),
                    '3' => array(
                        'alt' => esc_attr__('3 Columns','buscom'),
                        'img' => esc_url(  get_template_directory_uri() .'/assets/img/3col.jpg' )
                    ),
                    '4' => array(
                        'alt' => esc_attr__('4 Columns','buscom'),
                        'img' => esc_url( get_template_directory_uri(). '/assets/img/4col.jpg')
                    ),
                ),
                'default'  => '3'
            ),
            array(
                'id'       => 'buscom_woo_product_perpage',
                'type'     => 'text',
                'title'    => esc_html__( 'Product Per Page', 'buscom' ),
                'default' => '10'
            ),
            array(
                'id'       => 'buscom_product_details_custom_title',
                'type'     => 'text',
                'title'    => esc_html__( 'Product Details Title', 'buscom' ),
                'default'  => esc_html__( 'Shop Details', 'buscom' ),
                'required' => array('buscom_product_details_title_position','equals','below'),
            ),
            array(
                'id'       => 'buscom_product_details_custom_title',
                'type'     => 'text',
                'title'    => esc_html__( 'Product Details Title', 'buscom' ),
                'default'  => esc_html__( 'Shop Details', 'buscom' ),
                'required' => array('buscom_product_details_title_position','equals','below'),
            ),
            array(
                'id'       => 'buscom_woo_relproduct_display',
                'type'     => 'switch',
                'title'    => esc_html__( 'Related product Hide/Show', 'buscom' ),
                'subtitle' => esc_html__( 'Hide / Show related product in single page (Default Settings Show)', 'buscom' ),
                'default'  => '1',
                'on'       => esc_html__('Show','buscom'),
                'off'      => esc_html__('Hide','buscom')
            ),
            array(
                'id'        => 'woo_layout_mode',
                'type'      => 'select',
                'title'     => esc_html__( 'Select a layout', 'buscom' ),
                'subtitle'  => esc_html__( 'Select a layout for shop, shop single, product tag. product categories pages', 'buscom' ),
                'options'   => array(
                    '1' => esc_html__( 'Dark Mode', 'buscom'),
                    '2' => esc_html__( 'Light Mode', 'buscom'),
                ),
                'default'  => '2'
            ),
        ),
    ) );



    //Theme 404 error page styling
    Redux::setSection($opt_name, array(
        'icon'      => 'dashicons dashicons-visibility',
        'title'     => esc_html__('404 Error Settings', 'buscom'),
        'id'        => '404_settings',
        'fields'    => array( 
            array(
                'title'     => esc_html__('Heading Text', 'buscom'),
                'id'        => 'error_heading',
                'type'      => 'text',
                'default'   => esc_html__("404", 'buscom'),
            ),
            array(
                'title'     => esc_html__('Title', 'buscom'),
                'id'        => 'error_title',
                'type'      => 'text',
                'default'   => esc_html__('Sorry Page Was Not Found!', 'buscom'),
            ),
            array(
                'title'     => esc_html__('Subtitle', 'buscom'),
                'id'        => 'error_subtitle',
                'type'      => 'textarea',
                'default'   => esc_html__('We’re sorry, the page you have looked for does not exist in our database! Maybe  go to our home page   or try to use a search?', 'buscom'),
            ),
            array(
                'title'     => esc_html__('Home button label', 'buscom'),
                'id'        => 'error_home_btn_label',
                'type'      => 'text',
                'default'   => esc_html__('Go Back to home Page', 'buscom'),
            ),
        ),
    ));

    //Theme Blog Settings
    Redux::setSection($opt_name, array(
        'icon'      => 'el el-home',
        'title'     => esc_html__('Blog Settings', 'buscom'),
        'id'        => 'blog_settings',
        'fields'    => array( 
            array(
                'id'        => 'blog_sidebar',
                'type'      => 'select',
                'title'     => esc_html__( 'Select Blog post sidebar position', 'buscom' ),
                'options'   => array(
                    '1' => esc_html__( 'No Sidebar', 'buscom'),
                    '2' => esc_html__( 'Right Sidebar', 'buscom'),
                    '3' => esc_html__( 'Left Sidebar', 'buscom'),
                ),
                'default'  => '2'
            ),
            array(
                'id'               => 'blog_excerpt',
                'type'             => 'slider',
                'title'            => esc_html__('Excerpt Length', 'buscom'),
                'subtitle'         => esc_html__('How much words you want to show in blog page?','buscom'),
                'default'          => 40,
                'min'              => 10,
                'step'             => 2,
                'max'              => 130,
                'display_value'    => 'text'
            ),
            array(
                'id'        => 'read_more',
                'type'      => 'text',
                'title'     => esc_html__( 'Button Text', 'buscom'),
                'subtitle'  => esc_html__( 'Input Button Text it will show in button', 'buscom'),
                'default'   => esc_html__( 'Read More', 'buscom' ),
            ),
            array(
                'id'        => 'blog_layout_mode',
                'type'      => 'select',
                'title'     => esc_html__( 'Select a layout', 'buscom' ),
                'subtitle'  => esc_html__( 'Select a layout for blog, blog single, archive, category, tag, authore pages', 'buscom' ),
                'options'   => array(
                    '1' => esc_html__( 'Dark Mode', 'buscom'),
                    '2' => esc_html__( 'Light Mode', 'buscom'),
                ),
                'default'  => '2'
            ),
        ),
    ));


    //Theme Footer Settings
    Redux::setSection($opt_name, array(
        'icon'      => 'el el-credit-card',
        'title'     => esc_html__('Footer Settings', 'buscom'),
        'id'        => 'footer_settings',
        'fields'    => array( 
            array(
                'title'     => esc_html__('Footer Bottom Rgiht Content', 'buscom'),
                'id'        => 'copyright_txt',
                'type'      => 'textarea',
                'default'   => esc_html__('&copy; 2021 Validthemes. All rights reserved', 'buscom'),
            ),
            array(
                'title'     => esc_html__('Logo Light', 'buscom'),
                'subtitle'  => esc_html__( 'Upload here a light logo image file for footer', 'buscom' ),
                'id'        => 'footer_logo_light',
                'type'      => 'media',
                'url'       => true,
                'default'   => array(
                    'url'   => get_template_directory_uri().'/assets/img/logo-light.png'
                )
            ),
            array(
                'title'     => esc_html__('Logo Dark', 'buscom'),
                'subtitle'  => esc_html__( 'Upload here a dark logo image file for footer', 'buscom' ),
                'id'        => 'footer_logo_dark',
                'type'      => 'media',
                'url'       => true,
                'default'   => array(
                    'url'   => get_template_directory_uri().'/assets/img/logo.png'
                )
            ),
        ),
    ));

    /**
     * Filter hook for filtering the args. Good for child themes to override or add to the args array. Can also be used in other functions.
     * */
    if ( ! function_exists( 'change_arguments' ) ) {
        function change_arguments( $args ) {
            //$args['dev_mode'] = true;

            return $args;
        }
    }