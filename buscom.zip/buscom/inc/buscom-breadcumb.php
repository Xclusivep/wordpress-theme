<?php
// ** Breadcumb **/
if(!function_exists('buscom_breadcrumb')) {
    function buscom_breadcrumb(){
        
        $buscom_opt = get_option('buscom_redux_opt');

        if( !isset($buscom_opt['breadcumb_position']) || $buscom_opt['breadcumb_position'] == 1 || class_exists('woocommerce') ) { ?>
            <!-- Start Page Title 
            ============================================= -->
            <?php 
            if( class_exists('ReduxFramework') ) {
                if( !is_woocommerce() && ! is_page( 'cart' ) && !is_page( 'checkout' ) && !is_page( 'wishlist' ) && !is_page( 'my-account' )){ ?>
                    <div class="page-title-area text-center buscom-breadcrumb">
                <?php 
                }else{ ?>
                    <div class="page-title-area text-center text-light buscom-woo-breadcrumb">
                <?php
                } ?>
            <?php 
            }else { echo '<div class="page-title-area bg-dark text-center text-light">'; } ?>
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12">
                            <h1><?php if(is_front_page()) { echo esc_html__( 'Blog', 'buscom' ); } else { echo wp_title('');} ?></h1>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Page Title -->
            <!-- Start Breadcrumb 
            ============================================= -->
            <div class="breadcrumb-area bg-gray text-center">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12">
                            <ul class="breadcrumb">
                                <?php if(is_front_page()){ ?>
                                    <li><a href="<?php echo esc_url( home_url()); ?>"><i class="fas fa-home"></i> <?php echo esc_html__('Home', 'buscom');?></a>
                                    </li>
                                <?php } else{ ?>
                                    <li><a href="<?php echo esc_url( home_url()); ?>"><i class="fas fa-home"></i> <?php echo esc_html__('Home', 'buscom');?></a></li>
                                <?php buscom_breadcrumbs();
                                } ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Breadcrumb -->
            <?php
        }    
    }
}

if(!function_exists('buscom_breadcrumbs')) {
    function buscom_breadcrumbs(){
        global $post;

        $home = '<a href="'.esc_url(home_url('/')).'" title="'.esc_attr__( 'home', 'buscom' ).'">'.esc_html__('Home','buscom').'</a>';
        $showCurrent = 1;
        $homeLink = esc_url(home_url('/'));
        if ( is_front_page() ) { return; }  // don't display breadcrumbs on the homepage (yet)

        if( class_exists('woocommerce') ) {
            woocommerce_breadcrumb();
        }else{

            // echo wp_specialchars_decode( $home);

            if ( is_category() ) {
                // category section
                $thisCat = get_category(get_query_var('cat'), false);
                if (!empty($thisCat->parent)) echo get_category_parents($thisCat->parent, TRUE, ' ' . '/' . ' ');
                echo '<li class="active">'.  esc_html__('Archive for category','buscom').' "' . single_cat_title('', false) . '"' . '</li>';
            } elseif ( is_search() ) {
                // search section
                echo '<li class="active">' .  esc_html__('Search results for :','buscom').' "' . get_search_query() . '"' .'</li>';
            } elseif ( is_day() ) {
                echo '<li><a href="' . get_year_link(get_the_time('Y')) . '">' . get_the_time('Y') . '</a></li>';
                echo '<li><a href="' . get_month_link(get_the_time('Y'),get_the_time('m')) . '">' . get_the_time('F') . '</a> </li>';
                echo '<li>' . get_the_time('d') .'</li>';
            } elseif ( is_month() ) {
                // monthly archive
                echo '<li><a href="' . get_year_link(get_the_time('Y')) . '">' . get_the_time('Y') . '</a> </li>';
                echo '<li class="active">' . get_the_time('F') .'</li>';
            } elseif ( is_year() ) {
                // yearly archive
                echo '<li class="active">'. get_the_time('Y') .'</li>';
            } elseif ( is_single() && !is_attachment() ) {
                // single post or page
                if ( get_post_type() != 'post' ) {
                    $post_type = get_post_type_object(get_post_type());
                    $slug = $post_type->rewrite;
                    echo '<li><a href="' . $homeLink . '/?post_type=' . $slug['slug'] . '">' . $post_type->labels->singular_name . '</a></li>';
                    if ($showCurrent) echo '<li class="active">'. get_the_title() .'</li>';
                } else {
                    $cat = get_the_category(); if (isset($cat[0])) {$cat = $cat[0];} else {$cat = false;}
                    if ($cat) {$cats = get_category_parents($cat, TRUE, ' ' .' ' . ' ');} else {$cats=false;}
                    if (!$showCurrent && $cats) $cats = preg_replace("#^(.+)\s\s$#", "$1", $cats);
                    echo '<li>'.$cats.'</li>';
                    if ($showCurrent) echo '<li class="active">' . get_the_title() .'</li>';
                }
            } elseif ( !is_single() && !is_page() && get_post_type() != 'post' && !is_404() ) {
                // some other single item
                $post_type = get_post_type_object(get_post_type());
                echo '<li>' . $post_type->labels->singular_name .'<li>';
            } elseif ( is_attachment() ) {
                // attachment section
                $parent = get_post($post->post_parent);
                $cat = get_the_category($parent->ID); if (isset($cat[0])) {$cat = $cat[0];} else {$cat=false;}
                if ($cat) echo get_category_parents($cat, TRUE, ' ' . ' ' . ' ');
                echo '<li><a href="' . get_permalink($parent) . '">' . $parent->post_title . '</a></li>';
                if ($showCurrent) echo  '<li class="active">' . get_the_title() . '</li>';
            } elseif ( is_page() && !$post->post_parent ) {

                // parent page
                if ($showCurrent)
                    echo '<li class="active">' . get_the_title() . '</a></li>';
            } elseif ( is_page() && $post->post_parent ) {
                // child page
                $parent_id  = $post->post_parent;
                $breadcrumbs = array();

                while ($parent_id) {
                    $page = get_page($parent_id);
                    $breadcrumbs[] = '<li><a href="' . get_permalink($page->ID) . '">' . get_the_title($page->ID) . '</a></li>';
                    $parent_id  = $page->post_parent;
                }
                $breadcrumbs = array_reverse($breadcrumbs);
                for ($i = 0; $i < count($breadcrumbs); $i++) {

                    echo wp_specialchars_decode($breadcrumbs[$i]);
                    if ($i != count($breadcrumbs)-1);
                }
                if ($showCurrent) echo '<li class="active">' . get_the_title() . '</li>';
            } elseif ( is_tag() ) {
                // tags archive
                echo '<li>' .  esc_html__('Posts tagged','buscom').' "' . single_tag_title('', false) . '"' . '</li>';
            } elseif ( is_author() ) {
                // author archive
                global $author;
                $userdata = get_userdata($author);
                echo '<li class="active">' .  esc_html__('Articles posted by','buscom'). ' ' . $userdata->display_name . '</li>';
            } elseif ( is_404() ) {
                // 404
                echo '<li class="active">' .  esc_html__('Not Found','buscom') .'</li>';
            }

            if ( get_query_var('paged') ) {
                if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() );
                echo  '<li class="active">'.esc_html__('Page','buscom') . ' ' . get_query_var('paged').'</li>';
                if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() );
            }
        }
    }
}

function buscom_activate(){
    if( $counter==0 ){
        echo "activate in";
    }
}
add_action('action_init','buscom_activate');