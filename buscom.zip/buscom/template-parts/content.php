<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Buscom
 */
?>
<?php $buscom_opt = get_option('buscom_redux_opt');
if(has_post_thumbnail()){
	$class = 'single-item';
}else{
	$class = 'single-item thumb-less';
}
?>
<!-- Single Item -->
<div <?php post_class($class); ?>>
	<div class="item">
		<?php
	    $author_url = get_author_posts_url( get_the_ID(), get_the_author_meta( 'user_nicename' ) );
	    $author_id = get_the_author_meta('ID');
	    $author_gravatar = get_avatar_url($author_id, array('size' => 50));
	    if (has_post_thumbnail()) : ?>
			<div class="thumb">
	            <a href="<?php the_permalink(); ?>">
	                <?php the_post_thumbnail('buscom_945x441'); ?>
	            </a>
	        </div>
		<?php endif; ?>
	    <div class="info">
	        <div class="meta top">
	            <ul>
	                <li>
	                    <a href=" <?php echo esc_url( $author_url )?>"><i class="fas fa-user"></i><?php echo get_the_author()?></a>
	                </li>
	                <li>
	                    <i class="fas fa-calendar-alt"></i><?php echo get_the_date(); ?>
	                </li>
	            </ul>
	        </div>
	        <h3>
	            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
	        </h3>
	        <p>
	        	<?php
				if(!empty($buscom_opt['blog_excerpt'])){
	             	echo esc_attr(buscom_excerpt($buscom_opt['blog_excerpt'])); 
	            } else {
	             	echo esc_attr(buscom_excerpt(40)); 
	            }
			    ?> 
	        </p>
	        <a class="btn btn-theme effect btn-md" href="<?php the_permalink(); ?>">
	        	<?php
				if(!empty($buscom_opt['read_more'])){
		            echo wp_specialchars_decode(esc_html($buscom_opt['read_more']));
				} else {
					echo esc_html__( 'Read More', 'buscom' );
				}
				?>		
			</a>
	    </div>
	</div>
</div>
<!-- End Single Item -->