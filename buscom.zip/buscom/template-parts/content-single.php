<?php
/**
 * Template part for displaying single post content
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Buscom
 */
?>
<!-- Start Single Blog
============================================= -->
<div <?php post_class('item'); ?>>
    <div class="blog-item-box">
        <?php
        $author_url = get_author_posts_url( get_the_ID(), get_the_author_meta( 'user_nicename' ) );
		if(has_post_thumbnail() ) : ?>
            <div class="thumb">
                <a href="<?php the_permalink(); ?>">
                    <?php the_post_thumbnail('buscom_945x441'); ?>
                </a>
            </div>
        <?php
        endif;?>

        <div class="info">
            <div class="tags-date">

				<div class="post-meta">
					<ul>
						<li><i class="fas fa-calendar-alt"></i><?php echo get_the_date();?></li>
						<li><a href="<?php echo esc_url( $author_url )?>"><i class="fas fa-user"></i> <?php echo get_the_author(); ?></a></li>
					</ul>
				</div>
			</div>
            
			<?php
				the_content(); 
				$defaults = array(
					'before'           => '<div id="page-links">',
					'after'            => '</div>',
					'link_before'      => '',
					'link_after'       => '',
					'next_or_number'   => 'next',
					'separator'        => ' ',
					'nextpagelink'     => esc_html__( 'Continue reading', 'buscom' ),
					'previouspagelink' => esc_html__( 'Go back' , 'buscom'),
					'pagelink'         => '%',
					'echo'             => 1
				);
				wp_link_pages($defaults);
			?>
            <!-- Start Post Pagination -->
            <div class="post-pagi-area">
            	<?php
            	$prevpost = get_previous_post();
            	$nextpost = get_next_post();


            	if( ! empty( $prevpost ) ) {
	            	echo '<a href="'.esc_url( get_permalink( $prevpost->ID ) ).'"><i class="fas fa-angle-double-left"></i><span class="prev-post-pagination">'.esc_html__( 'Previous Post', 'buscom' ).'</span></a>';
	            }
	            if( ! empty( $nextpost ) ) {
	            	echo '<a href="'.esc_url( get_permalink( $nextpost->ID ) ).'"><span class="prev-post-pagination">'.esc_html__( 'Next Post', 'buscom' ).'</span><i class="fas fa-angle-double-right"></i></a>';
	            }
                ?>
            </div>
            <!-- End Post Pagination -->
			<?php if ( has_tag() ): ?>
	            <!-- Start Post Tag s-->
	            <div class="post-tags share">
	                <div class="tags">
	                    <span><?php echo esc_html( 'Tags:', 'buscom' ); ?> </span>
	                    <?php echo get_the_tag_list(); ?>
	                </div>
	            </div>
	            <!-- End Post Tags -->
        	<?php endif; ?>

        </div>
    </div>
</div>
<!-- End Blog -->