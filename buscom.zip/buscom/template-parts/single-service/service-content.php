<?php
/**
 * Template part for displaying  services single posts content
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package BUSCOM
 */

$service_column = is_active_sidebar( 'service-single-sidebar' ) ? '8' : '12';
$heading   = get_post_meta( get_the_ID(), '_heading', true );
?>

<div class="services-info col-md-<?php echo esc_attr($service_column); ?>">
    <?php
    if (has_post_thumbnail( )) :?>
        <div class="thumb">
            <?php the_post_thumbnail('buscom_750x500'); ?>
        </div>
    <?php endif; ?>

    <div class="info">
        <?php if (!empty($heading)) : ?>
            <h2><?php echo esc_html( $heading ); ?></h2>
        <?php endif; ?>
        <?php
            the_content(); 
            $defaults = array(
                'before'           => '<div id="page-links">',
                'after'            => '</div>',
                'link_before'      => '',
                'link_after'       => '',
                'next_or_number'   => 'next',
                'separator'        => ' ',
                'nextpagelink'     => esc_html__( 'Continue reading', 'buscom' ),
                'previouspagelink' => esc_html__( 'Go back' , 'buscom'),
                'pagelink'         => '%',
                'echo'             => 1
            );
            wp_link_pages($defaults);
        ?>  
    </div>
</div>