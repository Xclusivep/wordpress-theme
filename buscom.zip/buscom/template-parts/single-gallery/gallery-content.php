<?php
/**
 * Template part for displaying  gallery single posts content
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package BUSCOM
 */
?>
<div class="col-md-12">
	<?php
	$thumb = wp_get_attachment_image_src( get_post_meta( get_the_ID(), '_thumb_img_id', true ), 'buscom_1140x532' );

	$c_name 	= get_post_meta( get_the_ID(), '_client_name', true );
	$location 	= get_post_meta( get_the_ID(), '_location', true );
	$date 		= get_post_meta( get_the_ID(), '_date', true );
    $gallery_heading       = get_post_meta( get_the_ID(), '_gallery_heading', true );
	if(!empty($thumb)) : ?>

	    <div class="thumb">
	       <img src="<?php echo esc_url($thumb['0']) ?>" alt="<?php echo esc_attr( 'Thumb', 'buscom' ); ?>"> 
	    </div>
    <?php endif;?>
    <div class="info">
        <?php if (!empty($gallery_heading)) : ?>
            <h2><?php echo esc_html( $gallery_heading ); ?></h2>
        <?php endif; ?>
        <ul class="project-info">
        	<?php if (!empty($c_name)) : ?>
	            <li><strong><?php echo esc_html__('Client:', 'buscom'); ?></strong> <?php echo esc_html($c_name); ?></li>
	        <?php endif; ?>
            <li><strong><?php echo esc_html__('Category:', 'buscom'); ?></strong>
            	<?php
					$terms = get_the_terms( $post->ID , 'buscom-gallery-cat' );
					$i = 1; 
					foreach ( $terms as $term ) {
						$term_link = get_term_link( $term );
						if ($i == 1){echo ''; }else {echo ' , ';}
						echo esc_html($term->name) ;
						$i++;
					}
				?>
            </li>
            <?php if (!empty($date)) : ?>
            	<li><strong><?php echo esc_html__('Date:', 'buscom'); ?></strong> <?php echo esc_html($date); ?></li>
            <?php endif;?>
            <?php if (!empty($location)) : ?>
            	<li><strong><?php echo esc_html__('Address:', 'buscom'); ?></strong> <?php echo esc_html($location); ?></li>
            <?php endif;?>
        </ul>
        <?php
            the_content(); 
            $defaults = array(
                'before'           => '<div id="page-links">',
                'after'            => '</div>',
                'link_before'      => '',
                'link_after'       => '',
                'next_or_number'   => 'next',
                'separator'        => ' ',
                'nextpagelink'     => esc_html__( 'Continue reading', 'buscom' ),
                'previouspagelink' => esc_html__( 'Go back' , 'buscom'),
                'pagelink'         => '%',
                'echo'             => 1
            );
            wp_link_pages($defaults);
        ?>
    </div>
</div>