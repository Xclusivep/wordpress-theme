<?php
/**
 * Template part for displaying single post content
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Buscom
 */

get_header();
$buscom_opt = get_option('buscom_redux_opt');
buscom_breadcrumb();
$sidebar_position = $buscom_opt['blog_sidebar'];
$buscom_overide_sidebar_position =isset($_GET['sb'])? $_GET['sb']:$sidebar_position;
?>

<!-- Start Blog
============================================= -->
<?php

    if( isset( $buscom_opt['blog_sidebar'] ) ) { 
        if( $buscom_opt['blog_sidebar'] == '1' ){
            $layout = '';
        } elseif( $buscom_opt['blog_sidebar'] == '3' ){
            $layout = 'left-sidebar';
        } else {
            $layout = 'right-sidebar';
        }
    } else {
        $layout = 'right-sidebar';
    }
?>

<div class="blog-area single full-blog <?php echo esc_attr( $layout ); ?> full-blog default-padding">
    <div class="container">
        <div class="row">
            <div class="blog-items">
                <?php
                if( isset( $buscom_opt['blog_sidebar'] ) && $buscom_opt['blog_sidebar'] == '1' ) {
                    echo '<div class="blog-content col-md-10 col-md-offset-1">';
                }elseif( ! is_active_sidebar( 'primary-sidebar' )) {
                    echo '<div class="blog-content col-md-10 col-md-offset-1">';
                }else {
                    echo '<div class="blog-content col-md-8">';
                } ?>
                    <?php
                    if(have_posts()) :
                        while ( have_posts() ) :
                            the_post();

                            get_template_part( 'template-parts/content-single', get_post_type() );
                        endwhile; // End of the loop.
                    endif;
                    ?>

                    <?php
                    if( comments_open() || get_comments_number() ): ?>
                        <!-- Start Blog Comment -->
                        <?php comments_template(); ?>
                        <!-- End Comments Form -->
                    <?php 
                    endif; ?>     
                </div>
                <?php 
                if($buscom_overide_sidebar_position == '1'){
					echo "";
				}else{
					get_sidebar();
				}
                ?>
            </div>
        </div>
    </div>
</div>
<!-- End Blog -->
<?php get_footer();