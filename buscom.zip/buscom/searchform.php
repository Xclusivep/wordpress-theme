<?php
/**
 * The template for displaying custom search form
 *
 * @package BUSCOM
 */

add_filter('get_search_form', function($form) {
    $value = get_search_query() ? get_search_query() : '';
	$form =	'<form role="search" method="get" action="'.esc_url(home_url("/")).'">
				<input type="serch" name="s" class="form-control" placeholder="'.esc_attr__('Search Here...', 'buscom').'" value="'.esc_attr($value).'">
				<input type="submit" value="search">
			</form>';
    return $form;
});